package presenter;

import data.alert.Alert;
import data.event.Event;
import logic.builder.*;
import data.Clock;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import data.*;
import logic.CalendarFacade;

/**
 * the main system of this project, which observes the status controller. If there is an alert aroused, the main system would be notified.
 */
public class MainMenu implements Observer {
    private CalendarFacade calendarFacade; // the calendar system

    /**
     * construct a main menu
     */
    public MainMenu() {
        CalendarBuilder calendarBuilder = new CalendarBuilder();
        calendarBuilder.constructCalender();
        calendarFacade = calendarBuilder.getCalendar();
        Clock clock = new Clock();
        clock.addObserver(calendarFacade);
        calendarFacade.addObserverToStatusController(this);
        displayMenu();
    }

    /**
     * display the main menu
     */
    void displayMenu() {
        User user = new User("root", "123456");
        String option;
        Scanner in = new Scanner(System.in);
        do {
            System.out.print("\nCalendar System\n");
            System.out.print("1 - Log in\n");
            System.out.print("2 - Quit\n");
            System.out.print("Select Option:\n");
            option = in.nextLine();
            if (option.compareToIgnoreCase("1") == 0) {
                System.out.println("Enter username:");
                String name = in.nextLine();
                System.out.println("Enter password:");
                String password = in.nextLine();
                if (name.equals(user.getUserName()) && password.equals(user.getPassWord())) {
                    try {
                        doSelection(in);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
                    System.out.print("Error user name or password incorrect!:\n");
                }
            }
        } while (option.compareToIgnoreCase("2") != 0);
        System.out.print("\nExit System\n");
    }

    /**
     * Let user to create events
     *
     * @param in a scanner
     */
    private void createEvent(Scanner in) {
        System.out.println("\nSelect options:");
        System.out.println("1 - create a single event");
        System.out.println("2 - create a series of event");
        String opt = in.nextLine();
        if (opt.equals("1")) {
            try {
                EventBuilder eventBuilder = new EventBuilder(calendarFacade.getEventMaxId() + 1);
                eventBuilder.constructEvent();
                Event event = eventBuilder.getEvent();
                calendarFacade.addEvent(event);
                calendarFacade.updateEventStatus(new Date());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (opt.equals("2")) {
            try {
                FrequencyEventBuilder frequencyEventBuilder = new FrequencyEventBuilder(calendarFacade.getEventMaxId() + 1);
                List<Event> events = frequencyEventBuilder.getFrequencyEventList();
                for (Event event : events) {
                    calendarFacade.addEvent(event);
                }
                calendarFacade.updateEventStatus(new Date());
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }


    /**
     * allow user to search the event by tag
     *
     * @param in a scanner
     */
    private void searchByTag(Scanner in) {
        System.out.print("Input tag name\n");
        String tag = in.nextLine();
        for (Event event : calendarFacade.getEventByTag(tag))
            System.out.println(event.toString());
    }

    /**
     *  allow user to search the event by date
     *
     * @param in a scanner
     */
    private void searchByDate(Scanner in) {
        SimpleDateFormat SDF2 = new SimpleDateFormat("yyyy-MM-dd");
        Date date;
        while (true) {
            try {
                System.out.print("\nInput date (Date format is yyyy-MM-dd) :\n");
                String dateString = in.nextLine();
                date = SDF2.parse(dateString);
                break;
            } catch (ParseException e) {
                System.out.println("Please enter the date in correct format yyyy-MM-dd");
            }
        }
        for (Event event : calendarFacade.getEventByDate(date))
            System.out.println(event.toString());
    }

    /**
     *  allow user to search the event by name
     *
     * @param in a scanner
     */
    private void searchBySeriesName(Scanner in) {
        System.out.print("Input series name :\n");
        String seriesName = in.nextLine();
        for (Event event : calendarFacade.getEventBySerires(seriesName))
            System.out.println(event.toString());
    }

    /**
     * display all the events
     */
    private void displayAllEvents() {
        System.out.println("The followings are all existing events:");
        for (Event event : calendarFacade.getAllEvents()) {
            System.out.print(event.toString());
            String memo = calendarFacade.getRelatedMemo(event);
            if (memo != null)
                System.out.print(" - Memo:" + memo);
            System.out.print("\n");
        }
    }

    /**
     * allow user to search events by name
     *
     * @param in a scanner
     */
    private void searchByName(Scanner in) {
        System.out.println("Enter the name of the event:");
        String name = in.nextLine();
        for(Event event: calendarFacade.getEventByName(name))
            System.out.println(event.toString());
    }

    /**
     * Allow the user to view all the events
     *
     * @param in a scanner
     */
    private void viewEvents(Scanner in) {
        String opt;
        do {
            System.out.println("\nSelect options:");
            System.out.print("0 - View All Events with memo (if exist)\n");
            System.out.print("1 - View Past Events\n");
            System.out.print("2 - View Ongoing Events\n");
            System.out.print("3 - View Future Events\n");
            System.out.print("4 - Search by tag\n");
            System.out.print("5 - Search by date\n");
            System.out.print("6 - Search by series\n");
            System.out.println("7 - Search by name");
            System.out.println("8 - exit\n");
            opt = in.nextLine();
            if (opt.compareToIgnoreCase("0") == 0) {
                displayAllEvents();
            }
            if (opt.compareToIgnoreCase("1") == 0) {
                for (Event event : calendarFacade.getPastEvents()) {
                    System.out.println(event.toString());
                }
            }
            if (opt.compareToIgnoreCase("2") == 0) {
                for (Event event : calendarFacade.getOngoingEvents()) {
                    System.out.println(event.toString());
                }
            }
            if (opt.compareToIgnoreCase("3") == 0) {
                for (Event event : calendarFacade.getFutureEvents()) {
                    System.out.println(event.toString());
                }
            }
            if (opt.compareToIgnoreCase("4") == 0) {
                searchByTag(in);
            }
            if (opt.compareToIgnoreCase("5") == 0) {
                searchByDate(in);
            }
            if (opt.compareToIgnoreCase("6") == 0) {
                searchBySeriesName(in);
            }
            if (opt.compareToIgnoreCase("7") == 0) {
                searchByName(in);
            }
        } while (opt.compareToIgnoreCase("8") != 0);
        List<Event> events = calendarFacade.getAllEvents();
        for (Event event : events) {
            System.out.println(event.toString());
        }
    }

    /**
     * Let the user to create alerts.
     *
     * @param in a scanner
     * @throws Exception there is an error when writing file
     */
    private void createAlert(Scanner in) throws Exception {
        displayAllEvents();
        System.out.println("Enter the event the alert belong to (please enter event No.): ");
        Event event;
        while (true) {
            String data = in.nextLine();
            int number = Integer.parseInt(data);
            event = calendarFacade.getEventById(number);
            if (event == null)
                System.out.println("No. is not found!");
            else
                break;
        }
        System.out.println("Select option: ");
        System.out.println("1 - create a single alert");
        System.out.println("2 - create a series of alert until the event start");
        String opt = in.nextLine();
        if (opt.equals("1")) {
            AlertBuilder alertBuilder = new AlertBuilder(calendarFacade.getAlertMaxId() + 1);
            alertBuilder.constructAlert();
            Alert alert = alertBuilder.getAlert();
            calendarFacade.addAlert(alert);
            calendarFacade.addEventAlertConnection(event, alert);
        }
        if (opt.equals("2")) {
            FrequencyAlertBuilder frequencyAlertBuilder = new FrequencyAlertBuilder(calendarFacade.getAlertMaxId() + 1, event.getStartTime());
            List<Alert> alerts = frequencyAlertBuilder.getFrequencyAlerts();
            for (Alert alert : alerts) {
                calendarFacade.addAlert(alert);
                calendarFacade.addEventAlertConnection(event, alert);
            }
        }
    }

    /**
     * allow the user to view all the alerts
     *
     * @param in a scanner
     */
    private void viewAlerts(Scanner in) {
        System.out.println("\nSelect option:");
        System.out.println("1 - view all alerts");
        System.out.println("2 - view alerts belongs to an specific event");
        String opt = in.nextLine();
        if(opt.equals("1")) {
            System.out.println("\nThe followings are alerts");
            for (Alert alert : calendarFacade.getAllAlerts())
                System.out.println(alert.toString() + " of " + calendarFacade.getRelatedEvent(alert).toString());
        }
        else {
            displayAllEvents();
            System.out.println("Enter the event No. ");
            Event event;
            while (true) {
                String data = in.nextLine();
                int number = Integer.parseInt(data);
                event = calendarFacade.getEventById(number);
                if (event == null)
                    System.out.println("No. is not found!");
                else
                    break;
            }
            System.out.println("The followings are the alerts belonging to " + event.toString());
            for (Alert alert: calendarFacade.getRelatedAlerts(event))
                System.out.println(alert.toString());
        }
    }


    /**
     * Let user to create memos.
     *
     * @param in a scanner
     */
    private void createMemos(Scanner in) {
        System.out.println("\nEnter the memo:");
        String memo = in.nextLine();
        calendarFacade.addMemo(memo);
        System.out.println("The followings are existing events without memos:");
        for (Event event : calendarFacade.getAllEvents()) {
            if (calendarFacade.getRelatedMemo(event) == null)
                System.out.println(event.toString());
        }
        String eventId;
        Event event;
        do {
            System.out.println("Enter the the event associated with this memo (Please enter event No., enter noting if you've done): ");
            eventId = in.nextLine();
            if (eventId.equals(""))
                break;
            int number = Integer.parseInt(eventId);
            event = calendarFacade.getEventById(number);
            if (event == null || calendarFacade.getRelatedMemo(event) != null) {
                System.out.println("No. is not found!");
                continue;
            }
            calendarFacade.addEventMemoConnection(event, memo);
        } while (true);
    }

    /**
     * Allow the user to view memos
     *
     * @param in a scanner
     */
    private void viewMemos(Scanner in) {
        System.out.println("\nThe followings are memos:");
        for (String memo : calendarFacade.getMemos()) {
            System.out.println(memo);
        }
        String opt;
        do {
            System.out.println("\n0 - Exit");
            System.out.println("1 - See events associated with a memo");
            opt = in.nextLine();
            if (opt.compareToIgnoreCase("1") == 0) {
                System.out.println("Please select a memo: ");
                String memo = in.nextLine();
                System.out.println("The followings are the events associated with it.");
                try {
                    for (Event event : calendarFacade.getRelatedEvents(memo))
                        System.out.println(event);
                } catch (NullPointerException e) {
                    System.out.println("The memo does not exist!");
                }
            }
        } while (opt.compareToIgnoreCase("0") != 0);
    }

    /**
     * Let user to tag events
     *
     * @param in a scanner
     */
    private void tagEvent(Scanner in) {
        System.out.println("Enter the tag:");
        String tag = in.nextLine();
        displayAllEvents();
        String eventId;
        Event event;
        do {
            System.out.println("Enter the the event to be tagged (Please enter event No., enter noting if you've done): ");
            eventId = in.nextLine();
            if (eventId.equals(""))
                break;
            int number = Integer.parseInt(eventId);
            event = calendarFacade.getEventById(number);
            if (event == null) {
                System.out.println("No. is not found!");
                continue;
            }
            event.setTag(tag);
        } while (true);
    }

    /**
     * Let the user to add series name to the event
     *
     * @param in a scanner
     */
    private void addSeriesNameToEvent(Scanner in) {
        System.out.println("Enter the series name:");
        String seriesName = in.nextLine();
        displayAllEvents();
        String eventId;
        Event event;
        do {
            System.out.println("Enter the the event to be added to this series (Please enter event No., enter noting if you've done): ");
            eventId = in.nextLine();
            if (eventId.equals(""))
                break;
            int number = Integer.parseInt(eventId);
            event = calendarFacade.getEventById(number);
            if (event == null) {
                System.out.println("No. is not found!");
                continue;
            }
            event.setSeriesName(seriesName);
        } while (true);
    }

    /**
     * Let user to select one of the options.
     *
     * @param in a scanner
     * @throws Exception there is a error when writing file
     */
    private void doSelection(Scanner in) throws Exception {
        String option;
        do {
            System.out.print("\nCalendar System\n");
            System.out.print("0 - Exit\n");
            System.out.print("1 - Create Events\n");
            System.out.print("2 - View Events\n");
            System.out.print("3 - Create Alerts\n");
            System.out.print("4 - View Alerts\n");
            System.out.print("5 - Create Memos\n");
            System.out.print("6 - View Memos\n");
            System.out.println("7 - Tag Events");
            System.out.println("8 - Add Series Name to Events");
            System.out.print("Select Option:\n");
            option = in.nextLine();
            if (option.compareToIgnoreCase("1") == 0) createEvent(in);
            if (option.compareToIgnoreCase("2") == 0) viewEvents(in);
            if (option.compareToIgnoreCase("3") == 0) createAlert(in);
            if (option.compareToIgnoreCase("4") == 0) viewAlerts(in);
            if (option.compareToIgnoreCase("5") == 0) createMemos(in);
            if (option.compareToIgnoreCase("6") == 0) viewMemos(in);
            if (option.compareToIgnoreCase("7") == 0) tagEvent(in);
            if (option.compareToIgnoreCase("8") == 0) addSeriesNameToEvent(in);
        } while (option.compareToIgnoreCase("0") != 0);
        System.out.print("\nExit System\n");
    }

    /**
     * display that a alert is ringing.
     *
     * @param o the observable Logic.StatusController
     * @param arg the alert that is aroused
     */
    @Override
    public void update(Observable o, Object arg) {
        Alert alert = (Alert) arg;
        System.out.println(alert.toString() + " is ringing!");
    }

    public static void main(String[] args) {
        new MainMenu();
    }

}
