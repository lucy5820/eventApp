package data.memo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * the class that deal with information about memos
 */
public class MemoManager {
    private List<String> memos;

    /**
     * Construct a MemoManager in the system
     */
    public MemoManager() {
        memos = new ArrayList<>();
    }

    /**
     * add memo to the system
     * @param memo the context of the memo to be added
     */
    public void addMemo(String memo) {
        memos.add(memo);
        writeFile();
    }

    /**
     * Get all memos in the system
     * @return the list of all memos in the system
     */
    public List<String> getMemos() {
        return memos;
    }

    /**
     * write all memos created and store them into the Memo.csv file
     */
    private void writeFile() {
        File file = new File("src/data/files/Memos.csv");
        try {
            BufferedWriter writeText = new BufferedWriter(new FileWriter(file));
            for (String memo : memos) {
                writeText.write(memo);
                writeText.newLine();
            }
            writeText.flush();
            writeText.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}

