package data.event;

import logic.builder.CalendarBuilder;

import java.util.Date;

/**
 * an event in the calendar system
 */
public class Event {
    private String name;  // the name of the event
    private Date startTime;  // the start time of the event
    private Date endTime; // the end time of the event
    private String seriesName; // the series name of the event
    private String status; // the status of the event (Past, Ongoing or Future)
    private String tag; // the tag of the event
    private int id; // the id of the event


    /**
     * @param name the name of the event
     * @param id   the id of the event
     */
    public Event(String name, int id) {
        this.id = id;
        this.name = name;
    }

    /**
     * @return the name of the event
     */
    public String getName() {
        return name;
    }

    /**
     * @return the id of the event
     */
    public int getId() {
        return this.id;
    }

    /**
     * @return the start time of the event
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * set start time of the event
     *
     * @param startTime the start time assigned to the event
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime of the event
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * set the end time of the event
     *
     * @param endTime the end time assigned to the event
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the series name of the event
     */
    public String getSeriesName() {
        return seriesName;
    }

    /**
     * set the series name of the event
     *
     * @param seriesName the series name assigned to the event
     */
    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }

    /**
     * @return the status of the event
     */
    public String getStatus() {
        return status;
    }

    /**
     * set the status of the event
     *
     * @param status the status of the event
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the tag of the event
     */
    public String getTag() {
        return tag;
    }

    /**
     * set the tag of the event
     *
     * @param tag the tag of the event
     */
    public void setTag(String tag) {
        this.tag = tag;
    }

    @Override
    public String toString() {
        String result = "Event" + " {" + "No." + id +
                ", name: " + name +
                ", startTime: " + CalendarBuilder.SDF.format(startTime) +
                ", endTime: " + CalendarBuilder.SDF.format(endTime);
        if (seriesName != null)
            result = result + ", series: " + seriesName;
        if (tag != null)
            result = result + ", tag: " + tag;
        return result + "}";
    }
}