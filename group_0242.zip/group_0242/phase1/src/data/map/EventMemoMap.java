package data.map;

import data.event.EventManager;
import data.event.Event;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * a class used to deal with the information about relationship between Data.Managers.Items.Event and Memo.
 */
public class EventMemoMap {
    private Map<String, List<Integer>> connection; // the map store the relationship between Data.Managers.Items.Event and Memo
    private EventManager eventManager; // an eventManager related to this map

    /**
     * @param eventManager the eventManager related to this map
     */
    public EventMemoMap(EventManager eventManager) {
        connection = new HashMap<>();
        this.eventManager = eventManager;
    }

    /**
     * add a connection between a memo and an event
     *
     * @param memo a memo
     * @param event an event associated with this memo
     */
    public void addConnection(String memo, Event event) {
        int eventId = event.getId();
        if (connection.containsKey(memo)) {
            List<Integer> lst = connection.get(memo);
            lst.add(eventId);
        } else {
            List<Integer> lst = new ArrayList<>();
            lst.add(eventId);
            connection.put(memo, lst);
        }
        writeFile();
    }

    /**
     * add a connection between a memo and an event
     *
     * @param memo a memo
     * @param eventId the id of the event associated with this memo
     */
    public void addConnection(String memo, int eventId) {
        if (connection.containsKey(memo)) {
            List<Integer> lst = connection.get(memo);
            lst.add(eventId);
        } else {
            List<Integer> lst = new ArrayList<>();
            lst.add(eventId);
            connection.put(memo, lst);
        }
    }

    /**
     * get a list of Data.Managers.Items.Event associated with this memo
     *
     * @param memo an memo
     * @return a list of Data.Managers.Items.Event
     */
    public List<Event> getRelatedEvents(String memo) {
        List<Integer> lst = connection.getOrDefault(memo, new ArrayList<>());
        List<Event> result = new ArrayList<>();
        for (int id : lst) {
            Event event = eventManager.getEventById(id);
            result.add(event);
        }
        return result;
    }

    /**
     * get the memo that associated with the event
     *
     * @param event an event
     * @return an memo
     */
    public String getRelatedMemo(Event event) {
        for (Map.Entry<String, List<Integer>> entry : connection.entrySet()) {
            String key = entry.getKey();
            List<Integer> value = entry.getValue();
            if (value.contains(event.getId())) {
                return key;
            }
        }
        return null;
    }

    /**
     * write the information about the relationship between events and memos into a file "EventMemoMap.csv"
     */
    private void writeFile(){
        File file = new File("src/data/files/EventMemoMap.csv");
        try {
            BufferedWriter writeText = new BufferedWriter(new FileWriter(file));
            for (Map.Entry<String, List<Integer>> entry : connection.entrySet()) {
                String key = entry.getKey();
                List<Integer> value = entry.getValue();
                for (int id : value) {
                    writeText.write(key + "," + id);
                    writeText.newLine();
                }
            }
            writeText.flush();
            writeText.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}



