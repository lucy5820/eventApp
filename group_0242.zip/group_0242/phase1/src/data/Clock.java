package data;

import java.util.Date;
import java.util.Observable;
import java.util.concurrent.TimeUnit;

/**
 * a clock whose observer is Logic.CalendarFacade and it notify Logic.CalendarFacade every minute.
 */
public class Clock extends Observable {
    private static Date time; // the current time

    /**
     * Construct a clock using the system time
     */
    public Clock(){
        time = new Date();
        interval();
    }

    /**
     * Data.Clock automatically check the current time every second and notify its observers every minute
     */
    private void interval(){
        Thread thread = new Thread(() -> {
            while (true) {
                try {
                    TimeUnit.SECONDS.sleep(1);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                time = new Date();
                int milli = (int) (System.currentTimeMillis() % 60000);
                if (milli < 1000) {
                    setChanged();
                    notifyObservers(time);
                }
            }
        });

        thread.setDaemon(true);
        thread.start();
    }


}
