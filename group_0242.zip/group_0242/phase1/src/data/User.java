package data;

/**
 * a user in the calendar system
 */
public class User {

    private String userName; // the user's username

    private String passWord; // the user's account's password

    /**
     * Construct a new user
     * @param userName :name of the user to be constructed
     * @param passWord : password of the user to be constructed
     */
    public User(String userName, String passWord) {
        super();
        this.userName = userName;
        this.passWord = passWord;
    }

    /**
     * Get the user's username
     * @return the user's username
     */
    public String getUserName() {
        return userName;
    }


    /**
     * Get the user's password
     * @return the user's password
     */
    public String getPassWord() {
        return passWord;
    }


}
