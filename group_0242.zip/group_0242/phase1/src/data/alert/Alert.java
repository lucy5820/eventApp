package data.alert;

import java.util.Date;
import logic.builder.CalendarBuilder;

/**
 * an alert in the calendar system
 */
public class Alert {
    private Date time; // the time of the alert
    private int id; // the id of the alert

    /**
     * Construct a Data.Data.Managers.Items.Alert for an event
     * @param time: the time that this alert need to start to ring
     * @param id:   the identifier for a certain alert
     */
    public Alert(Date time, int id) {
        this.id = id;
        this.time = time;
    }

    /**
     * get the time that the alert should ring
     *
     * @return the time that the alert should ring
     */
    public Date getTime() {
        return time;
    }


    /**
     * get the int representation of identity of a certain alert
     * @return: the int representation of identity of a certain alert
     */
    public int getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Alert{" +
                "time: " + CalendarBuilder.SDF.format(time) +
                '}';
    }

}