package data.alert;

import logic.builder.CalendarBuilder;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * a class deal with all the alerts
 */
public class AlertManager {
    private List<Alert> alerts; // a list of alerts
    private int maxID; //the current max used id among alerts

    /**
     * Construct an AlertManager
     */
    public AlertManager() {
        this.maxID = 0;
        this.alerts = new ArrayList<>();
    }

    /**
     * Add an newly created alert into the system and update the maximum ID of all alerts in the system
     * @param alert : the alert to be added into the system
     */
    public void addAlert(Alert alert) {
        if (alert.getId() > maxID)
            maxID = alert.getId();
        alerts.add(alert);
        writeFile();
    }

    /**
     * Get the maximum ID of all alerts in the system
     * @return the maximum ID of all alerts in the system
     */
    public int getMaxId() {
        return maxID;
    }


    /**
     * Get an alert by inputting the Id associated with it
     * @param id : the ID associated with the alert need to get
     * @return: the alert need to find
     */
    public Alert getAlertById(int id) {
        for (Alert alert : alerts) {
            if (alert.getId() == id)
                return alert;
        }
        return null;
    }


    /**
     * Get all alerts in the system
     * @return the list of alerts stored in the system
     */
    public List<Alert> getAllAlert() {

        return this.alerts;
    }

    /**
     * Write all alerts currently exist in the system to a csv document called "Alerts.csv"
     */
    private void writeFile() {
        File file = new File("src/data/files/Alerts.csv");
        try {
            BufferedWriter writeText = new BufferedWriter(new FileWriter(file));
            for (Alert alert : alerts) {
                writeText.write(alert.getId() + "," + CalendarBuilder.SDF.format(alert.getTime()));
                writeText.newLine();
            }
            writeText.flush();
            writeText.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}




