package logic;

import data.event.EventManager;
import data.alert.Alert;
import data.alert.AlertManager;
import data.event.Event;
import data.memo.MemoManager;
import data.map.EventAlertMap;
import data.map.EventMemoMap;

import java.util.*;

/**
 * a class that contains six subsystems and this class is used to deal with all the things about the calendar system
 */
public class CalendarFacade implements Observer {

    private EventManager eventManager; // the eventManager to be constructed in the Logic.CalendarFacade
    private AlertManager alertManager; // the alertManager to be constructed in the Logic.CalendarFacade
    private MemoManager memoManager;// the memoManager to be constructed in the Logic.CalendarFacade
    private EventAlertMap eventAlertMap; // the event alert map to be constructed in the Logic.CalendarFacade
    private EventMemoMap eventMemoMap; // the event memo map to be constructed in the Logic.CalendarFacade
    private StatusController statusController; // the status controller to be constructed in the Logic.CalendarFacade

    /**
     * Construct a Logic.CalendarFacade
     */
    public CalendarFacade() {
        eventManager = new EventManager();
        alertManager = new AlertManager();
        memoManager = new MemoManager();
        eventAlertMap = new EventAlertMap(eventManager, alertManager);
        eventMemoMap = new EventMemoMap(eventManager);
        statusController = new StatusController(eventManager, alertManager);
    }

    /**
     * Update status of events and arose alerts when receiving the notification about time change from the clock
     * @param o : the subject observed by calender facade, which is clock in this case
     * @param arg: the time of clock that clock will notify its observer
     */
    @Override
    public void update(Observable o, Object arg) {
        Date now = (Date) arg;
        statusController.updateEventStatus(now);
        statusController.arouseAlert(now);
    }

    /**
     * Add observer to calendarFacade
     * @param o : the observer to be added to observe calendar facade, which is main menu in this case
     */
    public void addObserverToStatusController(Observer o) {
        statusController.addObserver(o);
    }

    /**
     * Get the maximum id of events in the system
     * @return the maximum id of current existing events in the system
     */
    public int getEventMaxId() {
        return eventManager.getMaxId();
    }

    /**
     * Get a certain event by its id
     * @param id the id associated with the event that needs to be found
     * @return: the event that the user needs to get
     */
    public Event getEventById(int id) {
        return eventManager.getEventById(id);
    }

    /**
     * Get the maximum id of alerts in the system
     * @return the maximum id of current existing alerts in the system
     */
    public int getAlertMaxId() {
        return alertManager.getMaxId();
    }

    /**
     * Add an event to the system
     * @param event the event that needs to be added
     */
    public void addEvent(Event event) {
        eventManager.addEvent(event);
    }

    /**
     * Add an alert to the system
     * @param alert the memo that needs to be added
     */
    public void addAlert(Alert alert) {
        alertManager.addAlert(alert);
    }

    /**
     * Add a memo to the system
     * @param memo the memo that needs to be added
     */
    public void addMemo(String memo) {
        memoManager.addMemo(memo);
    }

    /**
     * add a connection between an event and a alert to the map
     * @param event the event to be added to the map
     * @param alert the alert associated with the given event that will be added to the map
     */
    public void addEventAlertConnection(Event event, Alert alert) {
        eventAlertMap.addConnection(event, alert);
    }

    /**
     * add a connection between an event and a alert to the map
     * @param event the event to be added to the map
     * @param memo the memo associated with the given event that will be added to the map
     */
    public void addEventMemoConnection(Event event, String memo) {
        eventMemoMap.addConnection(memo, event);
    }

    /**
     * add a connection between an event and a alert to the map
     * @param eventId the id of event to be added to the map
     * @param alertId the id of alert associated with the given event that will be added to the map
     */
    public void addEventAlertConnection(int eventId, int alertId)  {
        eventAlertMap.addConnection(eventId, alertId);
    }

    /**
     * Get a list of alerts associated with a given event
     * @param event : the input event which needs to find its associated alerts
     * @return: the list of alerts associated with the given event
     */
    public List<Alert> getRelatedAlerts(Event event) {
        return eventAlertMap.getRelatedAlerts(event);
    }

    /**
     * Get an event associated with a given alert
     * @param alert : the alert which needs to find its associated event
     * @return the event associated to the given alert
     */
    public Event getRelatedEvent(Alert alert) {
        return eventAlertMap.getRelatedEvent(alert);
    }

    /**
     * add a connection between an event and a memo to the map
     * @param memo the memo to be added to the map
     * @param eventId the id of event associated with the given memo that will be added to the map
     */
    public void addEventMemoConnection(String memo, int eventId) {
        eventMemoMap.addConnection(memo, eventId);
    }

    /**
     * Get a list of events associated with a given memo
     * @param memo the memo whose associated events need to be found
     * @return the list of events that associated with the given memo
     */
    public List<Event> getRelatedEvents(String memo) {
        return eventMemoMap.getRelatedEvents(memo);
    }

    /**
     * Get the memo associated with a given event
     * @param event : the input event which needs to find its associated memo
     * @return: the memo associated to the given event
     */
    public String getRelatedMemo(Event event) {
        return eventMemoMap.getRelatedMemo(event);
    }

    /**
     * Get all memos stored in the system
     * @return the list of all memos in the system
     */
    public List<String> getMemos() {
        return memoManager.getMemos();
    }

    /**
     * Get all events stored in the system
     * @return the list of all events in the system
     */
    public List<Event> getAllEvents() {
        return eventManager.getAllEvents();
    }

    /**
     * Get all past events stored in the system
     * @return the list of all past events in the system
     */
    public List<Event> getPastEvents() {
        return eventManager.getPastEvents();
    }

    /**
     * Get all ongoing events stored in the system
     * @return the list of all ongoing events in the system
     */
    public List<Event> getOngoingEvents() {
        return eventManager.getOngoingEvents();
    }

    /**
     * Get all future events stored in the system
     * @return the list of all future events in the system
     */
    public List<Event> getFutureEvents() {
        return eventManager.getFutureEvents();
    }

    /**
     * Get all events associated to given series in the system
     * @return the list of all events associated with given series in the system
     */
    public List<Event> getEventBySerires(String series) {
        return eventManager.getEventBySerires(series);
    }

    /**
     * Get events with a given name in the system
     * @return the events associated with a given name in the system
     */
    public List<Event> getEventByName(String name) {
        return eventManager.getEventByName(name);
    }

    /**
     * Get all events with a given tag in the system
     * @return the list of events associated with a given tag in the system
     */
    public List<Event> getEventByTag(String tag) {
        return eventManager.getEventByTag(tag);
    }

    /**
     * Get all events associated with a given date in the system
     * @return the list of all events associated with a given date in the system
     */
    public List<Event> getEventByDate(Date date) {
        return eventManager.getEventByDate(date);
    }

    /**
     * Get all alerts stored in the system
     * @return the list of all alerts in the system
     */
    public List<Alert> getAllAlerts() {
        return alertManager.getAllAlert();
    }


    /**
     * Update all events' status stored in the system
     * @param now the current time
     */
    public void updateEventStatus(Date now) {
        statusController.updateEventStatus(now);
    }

}
