package logic.builder;

import data.alert.Alert;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;

/**
 * a builder for Alert
 */
public class AlertBuilder {
    private Alert alert; // an alert that would be constructed
    private int alertId;  // the id of the alert that would be constructed

    /**
     * Construct an AlertBuilder
     *
     * @param id: the value of id that will be associated with the alert to be created
     */
    public AlertBuilder(int id) {
        alertId = id;
    }

    /**
     * Get the alert created by the AlertBuilder
     * @return: the alert created
     */
    public Alert getAlert() {
        return this.alert;
    }


    /**
     * Check whether an input time a valid time or not
     *
     * @param time: the input time waiting to be checked whether
     * @return: return true if the input time is a valid time, or false if it is invalid
     */
    private boolean isVaildTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Construct an Data.Data.Managers.Items.Alert according to information provided by user, which is typed into the system
     * @throws ParseException: the string cannot be parsed
     */
    public void constructAlert() throws ParseException {
        Scanner in = new Scanner(System.in);
        String time;
        Date date = null;
        do {
            System.out.print("Input Start Time (Date format is yyyy-MM-dd HH:mm):\n");
            time = in.nextLine();
            if (!isVaildTime(time)) {
                System.out.println("Error:Date format is yyyy-MM-dd HH:mm!");
            } else {
                date = CalendarBuilder.SDF.parse(time);
            }
        } while (!isVaildTime(time));
        alert = new Alert(date, alertId);
        System.out.println("you successfully create an alert!");
    }
}
