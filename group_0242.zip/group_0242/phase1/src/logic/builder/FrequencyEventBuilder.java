package logic.builder;

import data.event.Event;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * A Builder of a series of Events
 */
public class FrequencyEventBuilder extends EventBuilder {
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm"); //SimpleDateFormat
    private List<Event> frequencyEventList = new ArrayList<>(); //list stores the frequency events
    private int frequency;//frequency of series of events
    private String duration;//duration of each event
    private int numOfEvents;//total number of events

    /**
     * Construct a Frequency event builder with eventId given
     *
     * @param eventId the id of event
     * @throws ParseException String Date cannot be parsed
     */
    public FrequencyEventBuilder(int eventId) throws ParseException {
        super(eventId);
        buildFrequencyEvent();
    }

    /**
     * get the list that stores frequency events
     *
     * @return the list that stores frequency events
     */
    public List<Event> getFrequencyEventList() {
        return frequencyEventList;
    }

    /**
     *return the date after the duration to Date
     *
     * @param date Date
     * @return a new date after the duration to Date
     */
    public Date addDuratonToDate(Date date) {
        Calendar c = Calendar.getInstance();
        String[] stringDuration = this.duration.split(":");
        c.setTime(date);
        c.add(Calendar.HOUR, Integer.parseInt(stringDuration[0]));
        c.add(Calendar.MINUTE, Integer.parseInt(stringDuration[1]));
        return c.getTime();
    }


    /**
     * set the new duration
     *
     * @param duration duration of each event
     */
    private void setDuration(String duration) {
        this.duration = duration;
    }

    /**
     * set the new frequency
     *
     * @param frequency frequency of events
     */
    private void setFrequency(int frequency) {
        this.frequency = frequency;
    }

    /**
     * set the new number of events
     *
     * @param numOfEvents the total number of events
     */
    private void setNumOfEvents(int numOfEvents) {
        this.numOfEvents = numOfEvents;
    }


    /**
     * Check whether the String positive is in the string format of positive numbers or not
     *
     * @param positive The String need to be tested
     * @return true if positive is in string format of positive numbers, false if it is not.
     */
    private boolean isValidPositive(String positive) {
        char[] chars = positive.toCharArray();
        if (positive.equals("") || chars[0] == '0') {
            return false;
        }
        for (char c : chars) {
            if (!Character.isDigit(c)) {
                return false;
            }
        }
        return true;
    }


    /**
     * Checked whether the String duration is in the String format of Date
     *
     * @param duration The String need to be tested
     * @return true if duration is in string format of Date, false if it is not
     */
    private boolean isValidDuration(String duration) {
        try {
            sdf.parse(duration);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Checked whether the frequency of events is less than the duration of each event of not
     *
     * @return true if the frequency of events is less than the duration of each event, false if it is not
     * @throws ParseException String Date cannot be parsed
     */
    private boolean checkFrequencyDuration() throws ParseException {
        return 0 < (sdf.parse(frequency * 24 + ":00")).compareTo(sdf.parse(duration));
    }


    /**
     * Set the frequency of events, if the input is not in the correct form as the description, then user need to
     * re-enter the frequency.
     *
     * @param in Scanner
     */
    public void setUserFrequency(Scanner in) {
        String input;
        do {
            System.out.print("Set the frequency(input the time interval of days, Ex: 7 means every 7 days): \n");
            input = in.nextLine();
            if (!isValidPositive(input)) {
                System.out.print("Error:Input a positive number that represent the number of days！" +
                        "(Do not start with a 0, such as 01) \n");
            } else {
                setFrequency(Integer.parseInt(input));
            }
        } while (!isValidPositive(input));
    }

    /**
     * Set the duration of event, if the input is not in the correct String format of Date, then user need to re-enter
     * the duration
     *
     * @param in Scanner
     */
    public void setUserDuration(Scanner in) {
        String userDuration;
        do {
            System.out.print("Input the duration of each event(Format HH:mm) \n");
            userDuration = in.nextLine();
            if (!isValidDuration(userDuration)) {
                System.out.print("Error: Please Enter in correct form! \n");
            } else {
                this.setDuration(userDuration);
            }
        } while (!isValidDuration(userDuration));
    }

    /**
     * Set the number of events, if the input is not in the correct form as the description, then user need to re-enter
     * the number of events
     *
     * @param in Scanner
     */
    public void setUserNumOfEvents(Scanner in) {
        String userNumOfEvents;
        do {
            System.out.print("Input the number of events \n");
            userNumOfEvents = in.nextLine();
            if (!isValidPositive(userNumOfEvents)) {
                System.out.print("Error:Enter positive number that represent the number of events! \n");
            } else {
                this.setNumOfEvents(Integer.parseInt(userNumOfEvents));
            }
        } while (!isValidPositive(userNumOfEvents));
    }

    /**
     * Get the start time of the events
     *
     * @param in Scanner
     * @return the valid start time of the events
     * @throws ParseException String Date cannot be parsed
     */
    private Date getStartTime(Scanner in) throws ParseException {
        String startTime;
        Date startDate = null;
        do {
            System.out.print("Input Start Time (Date format is yyyy-MM-dd HH:mm):\n");
            startTime = in.nextLine();
            if (!isVaildTime(startTime)) {
                System.out.println("Error:Date format is yyyy-MM-dd HH:mm");
            } else {
                startDate = CalendarBuilder.SDF.parse(startTime);
            }
        } while (!isVaildTime(startTime));
        return startDate;
    }

    /**
     * get the series name of events
     *
     * @param in Scanner
     * @return the series name of events
     */
    private String getSeriesName(Scanner in) {
        String seriesName;
        do {
            System.out.print("Input Series Name:\n");
            seriesName = in.nextLine();
            if (seriesName.equals(""))
                System.out.println("Name cannot be empty!");
        } while (seriesName.equals(""));
        return seriesName;
    }


    /**
     * build a series of frequency event
     *
     * @throws ParseException String Date cannot be parsed
     */
    public void buildFrequencyEvent() throws ParseException {
        Scanner in = new Scanner(System.in);
        String seriesName = getSeriesName(in);
        String name = getName(in);
        Date startTime = getStartTime(in);

        setUserFrequency(in);
        setUserDuration(in);
        setUserNumOfEvents(in);


        while (!checkFrequencyDuration()) {
            System.out.print("Your settings are not completely right, please reset frequency, " +
                    "duration and number of events (frequency cannot be shorter than duration)!\n");

            setUserFrequency(in);
            setUserDuration(in);
            setUserNumOfEvents(in);
        }

        Event firstEvent = new Event(name, eventId);

        firstEvent.setStartTime(startTime);
        firstEvent.setEndTime(addDuratonToDate(firstEvent.getStartTime()));
        firstEvent.setSeriesName(seriesName);

        Calendar c = Calendar.getInstance();
        c.setTime(firstEvent.getStartTime());
        frequencyEventList.add(firstEvent);

        for (int num = 1; num < numOfEvents; num++) {
            eventId++;
            Event newEvent = new Event(name, eventId);
            c.add(Calendar.DATE, this.frequency);
            newEvent.setStartTime(c.getTime());
            newEvent.setEndTime(addDuratonToDate(c.getTime()));
            newEvent.setSeriesName(seriesName);
            frequencyEventList.add(newEvent);
        }

        System.out.print("Success, you've created a number of frequency events");
    }
}
