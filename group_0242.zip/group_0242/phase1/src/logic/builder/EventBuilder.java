package logic.builder;

import data.event.Event;

import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;


/**
 * A builder of events
 */
public class EventBuilder {
    private Event event; //an Data.Managers.Items.Event
    protected int eventId; // the id of the event


    /**
     * Constructs a builder of events with eventId given
     *
     * @param eventId the id of the event
     */
    public EventBuilder(int eventId) {
        this.eventId = eventId;
    }

    /**
     * Check the String time is valid or not
     *
     * @param time The String Time that user entered
     * @return whether the time in Date format is valid or not
     */
    protected boolean isVaildTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * @return the current event
     */
    public Event getEvent() {
        return this.event;
    }

    /**
     * Set the name of the current event by user, if the input is empty then user need to re-enter the name.
     *
     * @param in Scanner
     * @return the name of event
     */
    protected String getName(Scanner in) {
        String name;
        do {
            System.out.print("Input event name:\n");
            name = in.nextLine();
            if (name.isEmpty()) {
                System.out.println("Error: event name must not empty!");
            }
        } while (name.isEmpty());
        return name;
    }

    /**
     * Set the start time and end time of the current event by user, if the input is not in the correct form or the end
     * date is smaller than the start date, the user need to re-enter the start time and end time until it is passed
     *
     * @param in Scanner
     * @throws ParseException String Date cannot be parsed
     */
    protected void setTime(Scanner in) throws ParseException {
        String startTime;
        Date startDate = null;
        do {
            System.out.print("Input Start Time (Date format is yyyy-MM-dd HH:mm):\n");
            startTime = in.nextLine();
            if (!isVaildTime(startTime)) {
                System.out.println("Error:Date format is yyyy-MM-dd HH:mm");
            } else {
                startDate = CalendarBuilder.SDF.parse(startTime);
            }
        } while (!isVaildTime(startTime));

        event.setStartTime(startDate);
        String endTime;
        Date endDate = null;
        boolean isError;
        do {
            System.out.print("Input End Time (Date format is yyyy-MM-dd HH:mm):\n");
            isError = false;
            endTime = in.nextLine();
            if (!isVaildTime(endTime)) {
                System.out.println("Error:Date format is yyyy-MM-dd HH:mm!");
            } else {
                endDate = CalendarBuilder.SDF.parse(endTime);
                assert startDate != null;
                if (endDate.getTime() < startDate.getTime()) {
                    System.out.println("Error:end date must > start date!");
                    isError = true;
                }
            }
        } while (!isVaildTime(endTime) || isError);

        event.setEndTime(endDate);
    }

    /**
     * Set the series name to the current event by user.
     *
     * @param in Scanner
     */
    protected void setSeries(Scanner in) {
        System.out.print("Input Series Name (if no Series Name just press enter):\n");
        String seriesName = in.nextLine();
        if (!seriesName.equals(""))
            event.setSeriesName(seriesName);
    }

    /**
     * Set the tag to the current event.
     *
     * @param in Scanner
     */
    protected void setTag(Scanner in) {
        System.out.print("Input Tag Name (if no Tag Name just press enter):\n");
        String tagName = in.nextLine();
        if (!tagName.equals(""))
            event.setTag(tagName);
    }

    /**
     * Construct a new event
     *
     * @throws ParseException String Date cannot be parsed.
     */
    public void constructEvent() throws ParseException {
        Scanner in = new Scanner(System.in);
        String name = getName(in);
        this.event = new Event(name, eventId);
        setTime(in);
        setSeries(in);
        setTag(in);
        System.out.print("you successfully create an event!\n");
    }


}
