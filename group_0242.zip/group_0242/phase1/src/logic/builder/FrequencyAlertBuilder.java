package logic.builder;

import data.alert.Alert;

import java.util.*;

/**
 * the builder for a series of alerts with frequency
 */
public class FrequencyAlertBuilder {
    private List<Alert> frequencyAlertList = new ArrayList<>(); // the series of alerts that would be created
    private String frequency; // the frequency of the series of alerts
    private Date endTime; // the end time of these series
    private int alertId; // the alertId assigned to alerts in this series

    /**
     * Construct a Logic.Builder.FrequencyAlertBuilder
     * @param id : the id associated with the alert to be created
     * @param endTime: the end time of the alert to be created
     */
    public FrequencyAlertBuilder(int id, Date endTime) {
        this.alertId = id;
        this.endTime = endTime;
        constructFrequencyAlert();
    }

    /**
     * Set the frequency of the alert
     * @param frequency : the frequency of alert to be built which is defined by user
     */
    private void setFrequency(String frequency) {
        this.frequency = frequency;
    }


    /**
     * Add a certain time frequency to the start time of an alert so as to get the time that the alert should notify
     * next time
     * @param start : the current start time of the alert
     * @return : the next start time that the alert should notify user
     */
    private Date timeAdding(Date start){
        Calendar c = Calendar.getInstance();
        int hours = Integer.parseInt(frequency.split(",")[0]) * 24 +
                Integer.parseInt(frequency.split(",")[1]);
        c.setTime(start);
        c.add(Calendar.HOUR, hours);
        return c.getTime();
    }

    /**
     * Check if the input frequency is a valid frequency or not
     * @param frequency : the input frequency defined by user
     * @return: return true if the input frequency is valid, false if not
     */
    private boolean isValidFrequency(String frequency) {
        if (!frequency.contains(",") || frequency.charAt(0) == ',') {
            return false;
        }
        String[] daysHours = frequency.split(",");
        if (daysHours.length < 2) {
            return false;
        }
        char[] days = daysHours[0].toCharArray();
        char[] hours = daysHours[1].toCharArray();
        if (Integer.parseInt(daysHours[1]) >= 24 || (days.length > 1 && days[0] == '0') || (hours.length > 1 && hours[0] == '0')) {
            return false;
        }
        for (char c : days) {
            for (char h : hours) {
                if (!Character.isDigit(c) || !Character.isDigit(h)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * set the frequency of an frequency alert
     * @param in : a scanner
     */
    private void setUserFrequency(Scanner in){
        String userFrequency;
        do {
            System.out.print("Set the frequency(format: day,hours ex. 2,23 means set the alert every 2 days " +
                    "and 23 hours): \n");
            userFrequency = in.nextLine();
            if (!isValidFrequency(userFrequency)) {
                System.out.print("Error:Please input in the correct format and also do not enter 1 as 01, " +
                        "also notice hours cannot be greater or equal to 24 \n");
            } else {
                this.setFrequency(userFrequency);
            }
        } while (!isValidFrequency(userFrequency));
    }

    /**
     * Construct frequency alerts
     */
    private void constructFrequencyAlert() {
        Scanner in = new Scanner(System.in);
        Date now = new Date();
        Alert firstAlert = new Alert(now, alertId);
        frequencyAlertList.add(firstAlert);

        setUserFrequency(in);

        Date currentEnd = timeAdding(now);

        while (currentEnd.compareTo(endTime) <= 0) {
            alertId++;
            Alert newAlert = new Alert(currentEnd, alertId);
            currentEnd = timeAdding(currentEnd);
            frequencyAlertList.add(newAlert);
        }

        System.out.println("Construct series of alerts successfully!");
    }

    /**
     * Get the list of frequency alerts created
     * @return the list of frequency alerts associated with a certain event
     */
    public List<Alert> getFrequencyAlerts() {
        return frequencyAlertList;
    }

}
