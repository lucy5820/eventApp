package logic.builder;

import data.alert.Alert;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import data.event.Event;
import logic.CalendarFacade;

/**
 * the builder for Logic.CalendarFacade
 */
public class CalendarBuilder {
    public static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm"); // the format of time
    private CalendarFacade calendarFacade; // the calendar Facade

    /**
     * Construct a calndar builder
     */
    public CalendarBuilder() {
        calendarFacade = new CalendarFacade();
    }

    /**
     * Get the calendar facade in the system
     * @return the calendar facade created
     */
    public CalendarFacade getCalendar() {
        return this.calendarFacade;
    }

    /**
     * Construct a calender
     */
    public void constructCalender() {
        constructEvents();
        constructAlerts();
        constructEventAlertMap();
        constructMemos();
        constructEventMemoMap();
        calendarFacade.updateEventStatus(new Date());
    }

    /**
     * Construct all events created before by reading the Events.csv file
     */
    private void constructEvents() {
        File file = new File("src/data/files/Events.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                String name = data[1];
                Event event = new Event(name, id);
                event.setStartTime(SDF.parse(data[2]));
                event.setEndTime(SDF.parse(data[3]));
                if (!data[4].equals("null"))
                    event.setSeriesName(data[4]);
                if (!data[5].equals("null"))
                    event.setTag(data[5]);
                calendarFacade.addEvent(event);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException | ParseException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Construct all alerts created before by reading the Alerts.csv file
     */
    private void constructAlerts() {
        File file = new File("src/data/files/Alerts.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                Date time = SDF.parse(data[1]);
                Alert alert = new Alert(time, id);
                calendarFacade.addAlert(alert);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException | ParseException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Construct the map which connect events and their associated alerts created before by
     * reading the EventAlertMap.csv file
     */
    private void constructEventAlertMap() {
        File file = new File("src/data/files/EventAlertMap.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                int eventId = Integer.parseInt(data[0]);
                int alertId = Integer.parseInt(data[1]);
                calendarFacade.addEventAlertConnection(eventId, alertId);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Construct all memos created before by reading the Memos.csv file
     */
    private void constructMemos() {
        File file = new File("src/data/files/Memos.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                calendarFacade.addMemo(data[0]);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Construct the map which connect events and their associated memos created before by
     * reading the EventMemoMap.csv file
     */
    public void constructEventMemoMap() {
        File file = new File("src/data/files/EventMemoMap.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                String memo = data[0];
                int eventId = Integer.parseInt(data[1]);
                calendarFacade.addEventMemoConnection(memo, eventId);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
