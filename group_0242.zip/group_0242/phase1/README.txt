Main function:  presenter.MainMenu
====================================
data.User can launch the calendar application by running the presenter.MainMenu class

Step 1
Start running presenter.MainMenu: there will be two options available:
1 - Log in 
2 - Quit

Select Option 2: user will exit the current calendar system

Select Option 1: system will require user to provider username and password

Note: By default, there exists only one user, and his username and password are “root” and “123456” separately. you can use this username and password to log in.

Step 2
After entering current username and password, 9 Options will be available
0 - Exit
1 - Create Events
2 - View Events
3 - Create Alerts
4 - View Alerts
5 - Create Memos
6 - View Memos
7 - Tag Events
8 - Add Series Name to Events

Select Option 0: user will exit the current calendar system

Select Option 1: user will be able to create events, and there are two kinds of events can be created
1 - create a single event
2 - create a series of event
data.User will be able to create events according to his or her needs, typing in the basic information of events to be created

Select Option 2: user will be able to view events recorded in his or her calendar system. He or she can choose to view events by time, tag, series or check past/ ongoing/ future events, and the following are options
0 - View All Events with memo (if exist)
1 - View Past Events
2 - View Ongoing Events
3 - View Future Events
4 - Search by tag
5 - Search by date
6 - Search by series
7 - exit 
(Option 7 will return back to previous page)

Select Option 3: user will be able to create alerts  
After selecting the event that the alert belongs to, enter the alert time then an alert will be created 

Select Option 4: user will be able to view all alerts recorded in his or her calendar system. 
He or she can check the alert time and detailed information all alerts associated with

Select Option 5: user will be able to create memos  
data.User will be asked to enter the context of memo he or she wants to add, and all events without memo will be displayed
Thus the user can make the choice to see which event to be associated to the memo

Select Option 6: user will be able to view memos recorded in his or her calendar system. 
After viewing all memos in the system, the user can also check events associated to a certain memo
By tying the context of a memo, events associated to it will be displayed


Select Option 7: user will be able to add a tag to an existing event in the system
After entering the tag to be added, user will be able to see all existing events in system and make the selection of events that he or she want to tag so as to tag specific events


Select Option 8: user will be able to add a series name to an existing event in the system
After entering the series name to be added, user will be able to see all existing events in system and make the selection of events that he or she want to add series to


Structure of phase 1 project:
====================================

2.1 Package

Three packages are built:
- calendardata
- calendarlogic
- calendarpresentation


2.2 Package calendardata



2.3 Package calendarlogic



2.4 Package calendarpresentation




