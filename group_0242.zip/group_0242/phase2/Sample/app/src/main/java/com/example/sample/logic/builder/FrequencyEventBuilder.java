package com.example.sample.logic.builder;

import com.example.sample.data.event.Event;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;


/**
 * A Builder of a series of Events
 */
public class FrequencyEventBuilder extends EventBuilder {
    private final SimpleDateFormat sdf = new SimpleDateFormat("HH:mm"); //SimpleDateFormat
    private List<Event> frequencyEventList = new ArrayList<>(); //list stores the frequency events
    private String duration;//duration of each event


    /**
     * Construct a Frequency event builder with eventId given
     *
     * @param eventId the id of event
     * @throws ParseException String Date cannot be parsed
     */
    public FrequencyEventBuilder(int eventId) {
        super(eventId);
    }

    /**
     * get the list that stores frequency events
     *
     * @return the list that stores frequency events
     */
    public List<Event> getFrequencyEventList() {
        return frequencyEventList;
    }

    /**
     *return the date after the duration to Date
     *
     * @param date Date
     * @return a new date after the duration to Date
     */
    public Date addDuratonToDate(Date date) {
        Calendar c = Calendar.getInstance();
        String[] stringDuration = this.duration.split(":");
        c.setTime(date);
        c.add(Calendar.HOUR, Integer.parseInt(stringDuration[0]));
        c.add(Calendar.MINUTE, Integer.parseInt(stringDuration[1]));
        return c.getTime();
    }


    /**
     * build a series of frequency event
     *
     * @throws ParseException String Date cannot be parsed
     */
    public void buildFrequencyEvent(String name,String duration,String startTime,String seriesName,
                                    int frequency,int numOfEvents,int userID){

        Event firstEvent = new Event(name, eventId);
        firstEvent.setUserId(userID);
        this.duration = duration;

        try {
            firstEvent.setStartTime( CalendarBuilder.SDF.parse(startTime));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        firstEvent.setEndTime(addDuratonToDate(firstEvent.getStartTime()));
        firstEvent.setSeriesName(seriesName);

        Calendar c = Calendar.getInstance();
        c.setTime(firstEvent.getStartTime());
        frequencyEventList.add(firstEvent);

        for (int num = 1; num < numOfEvents; num++) {
            eventId++;
            Event newEvent = new Event(name, eventId);
            c.add(Calendar.DATE, frequency);
            newEvent.setStartTime(c.getTime());
            newEvent.setEndTime(addDuratonToDate(c.getTime()));
            newEvent.setSeriesName(seriesName);
            newEvent.setUserId(userID);
            frequencyEventList.add(newEvent);
        }
    }
}
