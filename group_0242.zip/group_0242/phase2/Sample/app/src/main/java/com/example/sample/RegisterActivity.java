package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.UserBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

/**
 *  The RegisterActivity is a screen of the calendar app's interface
 *  when a new user register for the calendar system
 */
public class RegisterActivity extends AppCompatActivity {

    /**
     * username, password, confirmed password that input by users
     */
    private EditText userName, passWord, confirmPassWord;

    private Button registerButton, returnButton; // the Register Button and Return Button

    /**
     * Create all the static setup when creating the RegisterActivity, including initialization parts:
     * inflate the RegisterActivity's UI
     * interact with widges in UI. including Register Button and Return Button
     * @param savedInstanceState a bundle containing the RegisterActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        userName = findViewById(R.id.et_username);
        passWord = findViewById(R.id.et_password);
        confirmPassWord = findViewById(R.id.et_confirmPassword);
        registerButton = findViewById(R.id.btn_register);
        returnButton = findViewById(R.id.btn_return);
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkRegister()){
                    int maxID = CalendarFacade.getInstance().getUserMaxId();
                    UserBuilder userBuilder = new UserBuilder(maxID + 1);
                    userBuilder.constructUser(userName.getText().toString().trim(),passWord.getText().toString().trim());
                    User user = userBuilder.getUser();
                    CalendarFacade.getInstance().addUser(user);
                    writeFile(user);
                    Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(RegisterActivity.this,"Register fail！",Toast.LENGTH_SHORT).show();
                }

            }
        });
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Return to previous activity
                finish();
            }
        });
    }

    /**
     * @return whether the username and confirmed password is valid or not.
     */
    private boolean checkRegister() {
        if(userName.getText().toString().isEmpty() || passWord.getText().toString().isEmpty() || confirmPassWord.getText().toString().isEmpty()){
            return false;
        } else {
            if(CalendarFacade.getInstance().isUserExist(userName.getText().toString().trim())){
                return false;
            } else if(!(passWord.getText().toString().equals(confirmPassWord.getText().toString()))){
                return false;
            }
        }
        return true;
    }

    /**
     *write the new user in Users.csv
     *
     * @param user the new registered user
     */
    private void writeFile(User user) {
        try {
            FileOutputStream out = openFileOutput("Users.csv", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            osw.write(user.getId() + "," + user.getUserName() + "," +user.getPassWord());
            osw.write("\n");
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }
}
