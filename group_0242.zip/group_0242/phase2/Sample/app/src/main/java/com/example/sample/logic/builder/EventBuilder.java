package com.example.sample.logic.builder;

import com.example.sample.data.event.Event;
import java.text.ParseException;
import java.util.Date;
import java.util.Scanner;


/**
 * A builder of events
 */
public class EventBuilder {
    private Event event; //an Data.Managers.Items.Event
    protected int eventId; // the id of the event


    /**
     * Constructs a builder of events with eventId given
     *
     * @param eventId the id of the event
     */
    public EventBuilder(int eventId) {
        this.eventId = eventId;
    }

    /**
     * @return the current event
     */
    public Event getEvent() {
        return this.event;
    }

    /**
     * Construct a new event
     *
     * @throws ParseException String Date cannot be parsed.
     */
    public void constructSingleEvent(String name, String startTime, String endTime,String series,String tag, int userId) {
        try {
            this.event = new Event(name, CalendarBuilder.SDF.parse(startTime), CalendarBuilder.SDF.parse(endTime),series,tag,userId);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }


}
