package com.example.sample.data.user;

import java.util.ArrayList;
import java.util.List;

public class UserManager {

    private List<User> users;

    private int maxID; //the current max used id among alerts

    public UserManager() {
        this.maxID = 0;
        this.users = new ArrayList<>();
    }

    public void removeAll() {
        this.users = new ArrayList<>();
    }

    public void addUser(User user) {
        if (user.getId() > maxID)
            maxID = user.getId();
        users.add(user);
    }

    /**
     * Get the maximum ID of all users in the system
     * @return the maximum ID of all users in the system
     */
    public int getMaxId() {
        return maxID;
    }

    public boolean isExist(String username){
        if(getUserByName(username) != null){
            return true;
        }
        return false;
    }


    /**
     * Get a user by inputting the Id associated with it
     * @param name : the name associated with the user need to get
     * @return: the alert need to find
     */
    public User getUserByName(String name) {
        for (User user : users) {
            if (user.getUserName().equals(name))
                return user;
        }
        return null;
    }

    /**
     * Get a user by inputting the Id associated with it
     * @param id : the ID associated with the user need to get
     * @return: the alert need to find
     */
    public User getUserById(int id) {
        for (User user : users) {
            if (user.getId() == id)
                return user;
        }
        return null;
    }

    /**
     * Get all users in the system
     * @return the list of alerts stored in the system
     */
    public List<User> getAllUsers() {

        return this.users;
    }
}
