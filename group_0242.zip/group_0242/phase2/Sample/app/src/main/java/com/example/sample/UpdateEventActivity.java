package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

/**
 *  The UpdateEventActivity is a screen of the calendar app's interface
 *  when update the data of events
 */
public class UpdateEventActivity extends AppCompatActivity {
    /**
     * name of the event, start time, end time, series name, tag name and invited users input by the user
     */
    EditText eventName, startTime, endTime, series, tag, inviteName;
    Button invite,update,delete,back;// Invite Button, Update Button, Delete Button and Back Button
    private Event event;//current event
    private User user;// current login user

    /**
     * Create all the static setup when creating the UpdateEventActivity, including initialization parts:
     * inflate the UpdateEventActivity's UI
     * interact with widges in UI. including Invite Button, Update Button, Delete Button, Back Button
     * unbind data sets of users to get the information of the current user
     * unbind data sets of events to get the information of the current event
     * @param savedInstanceState a bundle containing the UpdateEventActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_event);
        eventName = findViewById(R.id.tv_eventName);
        startTime = findViewById(R.id.tv_startTime);
        endTime = findViewById(R.id.tv_endTime);
        series = findViewById(R.id.tv_series);
        inviteName = findViewById(R.id.tv_userId);
        tag = findViewById(R.id.tv_tag);
        invite = findViewById(R.id.invite);
        update = findViewById(R.id.update);
        delete = findViewById(R.id.btn_delete);
        back = findViewById(R.id.btn_back);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
            event = (Event) bundle.getSerializable("event");
            event = CalendarFacade.getInstance().getEventById(event.getId());
        }
        eventName.setText(event.getName());
        startTime.setText(CalendarBuilder.SDF.format(event.getStartTime()));
        endTime.setText(CalendarBuilder.SDF.format(event.getEndTime()));
        series.setText(event.getSeriesName());
        inviteName.setText(event.getInviteUser() == null ? "":event.getInviteUser());
        tag.setText(event.getTag());
        invite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Invite Users when clicking the Invite Button
                if(!inviteName.getText().toString().isEmpty()) {
                    String name = inviteName.getText().toString().trim();
                        if(CalendarFacade.getInstance().getUserByName(name) != null) {
                            if(name.equals(user.getUserName())) {
                                Toast.makeText(UpdateEventActivity.this,"You can not invite yourself！",Toast.LENGTH_SHORT).show();
                            }
                            if(user.getId() != event.getUserId()) {
                                Toast.makeText(UpdateEventActivity.this,"You can not the event owner, you can not invite others！",Toast.LENGTH_SHORT).show();
                            }
                            event.setInviteUser(name);
                            writeEventsToFile(CalendarFacade.getInstance().getSystemAllEvents());
                            Toast.makeText(UpdateEventActivity.this,"Invite success！",Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(UpdateEventActivity.this,"People not exist！",Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(UpdateEventActivity.this,"User id must be int！",Toast.LENGTH_SHORT).show();
                    }

            }
        });
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //update event when clicking the Update Button
                //return to EventManageActivity if succeed
                //bind data sets of user to the list
                if(checkUpdate()) {
                    event.setName(eventName.getText().toString().trim());
                    try {
                        event.setStartTime(CalendarBuilder.SDF.parse(startTime.getText().toString().trim()));
                        event.setEndTime(CalendarBuilder.SDF.parse(endTime.getText().toString().trim()));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    event.setSeriesName(series.getText().toString().trim());
                    event.setTag(tag.getText().toString().trim());

                    writeEventsToFile(CalendarFacade.getInstance().getSystemAllEvents());
                }
                Intent intent = new Intent(UpdateEventActivity.this, EventManageActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //delete current Event when clicking Delete Button
                //return to EventManageActivity if succeed
                //bind data sets of users to the list
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateEventActivity.this);
                builder.setTitle("Warnning:").setMessage("Are you sure delete this event?").setIcon(R.drawable.icon_user).setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        event = CalendarFacade.getInstance().getEventById(event.getId());
                        CalendarFacade.getInstance().getSystemAllEvents().remove(event);
                        writeEventsToFile(CalendarFacade.getInstance().getSystemAllEvents());
                        Intent intent = new Intent(UpdateEventActivity.this, EventManageActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("user", user);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();

            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            //return to previous Activity
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    /**
     * write the events in Events.csv
     *
     * @param events current events
     */
    private void writeEventsToFile(List<Event> events) {
        try {
            FileOutputStream out = openFileOutput("AllEvents.csv", Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for(Event event : events){
                osw.write(event.getId() + "," + event.getName() + "," + CalendarBuilder.SDF.format(event.getStartTime()) + ","
                        + CalendarBuilder.SDF.format(event.getEndTime()) + "," +
                        event.getSeriesName() + "," + event.getTag() + "," +event.getUserId() + "," + event.getInviteUser()+","+event.isConfirm());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

    /**
     *return True if the String time is in the correct time form, vice versa
     *
     * @param time time
     * @return whether the String time is in the time form
     */
    private boolean isValidTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * return true if the event is valid,vice versa
     *
     * @return the updated event is valid or not
     */
    private boolean checkUpdate() {
        if(eventName.getText().toString().isEmpty() || startTime.getText().toString().isEmpty() || endTime.getText().toString().isEmpty()
        || series.getText().toString().isEmpty() || tag.getText().toString().isEmpty()) {
            Toast.makeText(UpdateEventActivity.this,"Can not empty！",Toast.LENGTH_SHORT).show();
            return false;
        }

        if(!isValidTime(startTime.getText().toString().trim()) || !isValidTime(endTime.getText().toString().trim())){
            Toast.makeText(UpdateEventActivity.this,"Date format yyyy-MM-dd HH:mm！",Toast.LENGTH_SHORT).show();
            return false;
        } else {
            try {
                Date startDate = CalendarBuilder.SDF.parse(startTime.getText().toString().trim());
                Date endDate = CalendarBuilder.SDF.parse(endTime.getText().toString().trim());
                if(endDate.getTime() < startDate.getTime()){
                    Toast.makeText(UpdateEventActivity.this,"start time should before end time！",Toast.LENGTH_SHORT).show();
                    return false;
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }
        return true;
    }


}
