package com.example.sample.data.map;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.alert.AlertManager;
import com.example.sample.data.event.Event;
import com.example.sample.data.event.EventManager;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

/**
 * a class used to deal with the information about relationship between Data.Managers.Items.Event and Data.Data.Managers.Items.Alert.
 */
public class EventAlertMap {
    private Map<Integer, List<Integer>> connection; // the map store the relationship between Data.Managers.Items.Event and Data.Data.Managers.Items.Alert
    private EventManager eventManager; // an Data.Managers.Event.EventManager related to the map
    private AlertManager alertManager; // an AlertManger related to the map

    /**
     * Construct an Data.Map.EventAlertMap
     *
     * @param eventManager an Data.Managers.Event.EventManager related to the map
     * @param alertManager an AlertManger related to the map
     */
    public EventAlertMap(EventManager eventManager, AlertManager alertManager) {
        connection = new HashMap<>();
        this.eventManager = eventManager;
        this.alertManager = alertManager;
    }

    /**
     * add a connection of an event and an alert into the map connection
     *
     * @param event an event
     * @param alert an alert belonging to the event
     */
    public void addConnection(Event event, Alert alert) {
        int eventId = event.getId();
        int alertId = alert.getId();
        if (connection.containsKey(eventId)) {
            List<Integer> lst = connection.get(eventId);
            lst.add(alertId);
        } else {
            List<Integer> lst = new ArrayList<>();
            lst.add(alertId);
            connection.put(eventId, lst);
        }
        writeFile();
    }

    public Map<Integer, List<Integer>> getConnection() {
        return connection;
    }

    /**
     * add a connection of an event and an alert into the map connection
     *
     * @param eventId the id of the event
     * @param alertId the id of the alert belonging to the event
     */
    public void addConnection(int eventId, int alertId) {
        if (connection.containsKey(eventId)) {
            List<Integer> lst = connection.get(eventId);
            lst.add(alertId);
        } else {
            List<Integer> lst = new ArrayList<>();
            lst.add(alertId);
            connection.put(eventId, lst);
        }
    }

    /**
     * get a list of alert belonging to the event
     *
     * @param event an event
     * @return a list of Data.Data.Managers.Items.Alert
     */
    public List<Alert> getRelatedAlerts(Event event) {
        List<Integer> lst = connection.get(event.getId());
        List<Alert> result = new ArrayList<>();
        for (int id : lst) {
            Alert alert = alertManager.getAlertById(id);
            if (alert != null)
                result.add(alert);
        }
        return result;
    }


    /**
     * return the event that the alert belongs to
     *
     * @param alert an alert
     * @return the event that the alert belongs to
     */
    public Event getRelatedEvent(Alert alert) {
        for (Map.Entry<Integer, List<Integer>> entry : connection.entrySet()) {
            int key = entry.getKey();
            List<Integer> value = entry.getValue();
            if (value.contains(alert.getId())) {
                return eventManager.getEventById(key);
            }
        }
        return null;
    }

    /**
     * write the information about the relationship between alerts and events into the file "EventAlertMap.csv".
     *
     */
    private void writeFile(){
        File file = new File("src/files/EventAlertMap.csv");
        try {
            BufferedWriter writeText = new BufferedWriter(new FileWriter(file));
            for (Map.Entry<Integer, List<Integer>> entry : connection.entrySet()) {
                int key = entry.getKey();
                List<Integer> value = entry.getValue();
                for (int id : value) {
                    writeText.write(key + "," + id);
                    writeText.newLine();
                }
            }
            writeText.flush();
            writeText.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}
