package com.example.sample.data.user;

import java.io.Serializable;

/**
 * a user in the calendar system
 */
public class User implements Serializable {

    private String userName; // the user's username

    private String passWord; // the user's account's password

    private int id;// the id of the user

    /**
     * Construct a new user
     * @param userName :name of the user to be constructed
     * @param passWord : password of the user to be constructed
     */
    public User(String userName, String passWord, int id) {
        super();
        this.userName = userName;
        this.passWord = passWord;
        this.id = id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    /**
     * Get the user's username
     * @return the user's username
     */
    public String getUserName() {
        return userName;
    }


    /**
     * Get the user's password
     * @return the user's password
     */
    public String getPassWord() {
        return passWord;
    }


}
