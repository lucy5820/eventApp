package com.example.sample.data.memo;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * the class that deal with information about memos
 */
public class MemoManager {
    private List<Memo> memos;
    private int maxID;

    /**
     * Construct a MemoManager in the system
     */
    public MemoManager() {
        this.maxID = 0;
        memos = new ArrayList<>();
    }

    public void removeAll() {
        memos = new ArrayList<>();
    }

    /**
     * add memo to the system
     * @param memo the context of the memo to be added
     */
    public void addMemo(Memo memo) {
        if (memo.getId() > maxID)
            maxID = memo.getId();
        memos.add(memo);
    }

    public int getMaxId() {
        return maxID;
    }

    /**
     * Get all memos in the system
     * @return the list of all memos in the system
     */
    public List<Memo> getMemos() {
        return memos;
    }

    public Memo getMemoById(int id) {
        for(Memo memo : memos){
            if (memo.getId() == id) {
                return memo;
            }
        }
        return null;
    }

    public List<Memo> getMyMemos(int userID) {
        List<Memo> myMemos = new ArrayList<>();
        for(Memo memo : memos) {
            if(memo.getUserId() == userID) {
                myMemos.add(memo);
            }
        }
        return myMemos;
    }
}

