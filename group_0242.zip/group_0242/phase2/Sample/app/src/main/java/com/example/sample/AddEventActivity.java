package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;
import com.example.sample.logic.builder.EventBuilder;
import com.example.sample.logic.builder.FrequencyEventBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 *  The AddEventActivity is a screen of the calendar app's interface
 *  when users add events to system
 */
public class AddEventActivity extends AppCompatActivity {

    LinearLayout singleSetting, seriesSetting;
    EditText eventName, startTime, duration, seriesName, number, frequency, singleEventName, singleStartTime, endTime, singleSeriesName, singletagName;;
    Button createButton, returnButton, singleCreateButton, singleReturnButton;
    RadioGroup radioButton;
    private User user;

    /**
     * Create all the static setup when creating the AddEventActivity,
     * including initialization parts:
     * inflate the AddEventActivity's UI
     * interact with widges in UI
     * bind data sets of events to the list for a certain user
     * @param savedInstanceState a bundle containing the AddEventActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        singleSetting = (LinearLayout) findViewById(R.id.singleLinear);
        singleSetting.setVisibility(View.GONE);
        seriesSetting = (LinearLayout) findViewById(R.id.seriesLinear);
        singleSetting.setVisibility(View.GONE);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        radioButton = findViewById(R.id.filterOptions);
        radioButton.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup unused, int checkedId) {
                // checkedId is the R.id constant of the currently checked RadioButton
                // Your code here: make only the selected mode's settings group visible
                if (checkedId == R.id.single) {
                    seriesSetting.setVisibility(View.GONE);
                    singleSetting.setVisibility(View.VISIBLE);
                    singleEventName = findViewById(R.id.single_eventName);
                    endTime = findViewById(R.id.single_endDate);
                    singleStartTime = findViewById(R.id.single_startDate);
                    singleSeriesName = findViewById(R.id.single_series);
                    singletagName = findViewById(R.id.single_tag);
                }

                if (checkedId == R.id.series) {
                    singleSetting.setVisibility(View.GONE);
                    seriesSetting.setVisibility(View.VISIBLE);
                    eventName = findViewById(R.id.et_eventName);
                    startTime = findViewById(R.id.et_startDate);
                    duration = findViewById(R.id.et_duration);
                    seriesName = findViewById(R.id.et_seriesName);
                    number = findViewById(R.id.et_number);
                    frequency = findViewById(R.id.et_frequency);
                }
            }
        });

        createButton = findViewById(R.id.btn_create);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                if(checkAdd(1)){
                    int maxID = CalendarFacade.getInstance().getEventMaxId();
                    FrequencyEventBuilder frequencyEventBuilder = new FrequencyEventBuilder(maxID+1);
                    frequencyEventBuilder.buildFrequencyEvent(eventName.getText().toString().trim(),duration.getText().toString().trim(),startTime.getText().toString().trim(),
                            seriesName.getText().toString().trim(),Integer.parseInt(frequency.getText().toString().trim()),
                            Integer.parseInt(number.getText().toString().trim()),user.getId());
                    List<Event> events = frequencyEventBuilder.getFrequencyEventList();
                    for (Event event : events) {
                        CalendarFacade.getInstance().addEvent(event);
                    }
                    writeEventsToFile(events);
                    Intent intent = new Intent(AddEventActivity.this, EventManageActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("user", user);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    Toast.makeText(AddEventActivity.this,"Add success！",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(AddEventActivity.this,"Add fail！",Toast.LENGTH_SHORT).show();
                }

            }
        });

        singleCreateButton = findViewById(R.id.single_create);
        singleCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                if(checkAdd(0)){
                    int maxID = CalendarFacade.getInstance().getEventMaxId();
                    EventBuilder eventBuilder = new EventBuilder(maxID + 1);
                    eventBuilder.constructSingleEvent(singleEventName.getText().toString().trim(),singleStartTime.getText().toString().trim(),
                            endTime.getText().toString().trim(),singleSeriesName.getText().toString().trim(),singletagName.getText().toString().trim(),
                            user.getId());
                    Event event = eventBuilder.getEvent();
                    CalendarFacade.getInstance().addEvent(event);
                    writeFile(event);
                    Intent intent = new Intent(AddEventActivity.this, EventManageActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("user", user);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    Toast.makeText(AddEventActivity.this,"Add success！",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(AddEventActivity.this,"Add fail！",Toast.LENGTH_SHORT).show();
                }

            }
        });
        singleReturnButton = findViewById(R.id.single_return);
        singleReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                finish();
            }
        });
        returnButton = findViewById(R.id.btn_return);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                finish();
            }
        });
    }

    /**
     * Check if it is a valid operation to add an event to the system
     * @param i represent the type of the event to be added
     * @return return True if and only if the operation to add an event is valid
     */
    private boolean checkAdd(int i){
        if(i == 0){
            if(singleEventName.getText().toString().isEmpty() || singleStartTime.getText().toString().isEmpty() || endTime.getText().toString().isEmpty()) {
                Toast.makeText(AddEventActivity.this,"Can not empty！",Toast.LENGTH_SHORT).show();
                return false;
            }
            if(!isValidTime(singleStartTime.getText().toString().trim()) || !isValidTime(endTime.getText().toString().trim())){
                Toast.makeText(AddEventActivity.this,"Date format yyyy-MM-dd HH:mm！",Toast.LENGTH_SHORT).show();
                return false;
            } else{
                try {
                    Date startDate = CalendarBuilder.SDF.parse(singleStartTime.getText().toString().trim());
                    Date endDate = CalendarBuilder.SDF.parse(endTime.getText().toString().trim());
                    if(endDate.getTime() < startDate.getTime()){
                        return false;
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }


            }

        } else if (i == 1) {
            if(seriesName.getText().toString().isEmpty() || eventName.getText().toString().isEmpty() || startTime.getText().toString().isEmpty()
            || frequency.getText().toString().isEmpty() || duration.getText().toString().isEmpty() || number.getText().toString().isEmpty()) {
                return false;
            }

            if(!checkFrequencyDuration() || !isInt(number.getText().toString().trim()) || !isInt(frequency.getText().toString().trim())){
                Toast.makeText(AddEventActivity.this,"input the time interval of days, Ex: 7 means every 7 days,Duration Format HH:mm！",Toast.LENGTH_SHORT).show();
                return false;
            }
            return true;
        }

        return true;
    }

    /**
     * Check if the input can be represented by int in base 10
     * @param input the input value to be checked
     * @return true if the input can be represented by int in base 10
     */
    private boolean isInt(String input){
        try{
            Integer.parseInt(input);
        }catch (Exception e){
            return false;
        }
        return true;
    }

    /**
     * Check if the frequency duration of the event is a valid or not
     * @return: return true if the event's frequency duration is valid, false if not
     */
    private boolean checkFrequencyDuration(){
        try {
            int fre = Integer.parseInt(frequency.getText().toString().trim());
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");
            return 0 < (sdf.parse(fre * 24 + ":00")).compareTo(sdf.parse(duration.getText().toString().trim()));
        } catch (ParseException e) {
            return false;
        }
    }

    /**
     * Check if the input time is a valid time or not
     * @param time : the input time
     * @return: return true if the input time is valid, false if not
     */
    private boolean isValidTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * write a single event of the system into file Events.txt
     * @param event the event created and stored in the system which needs to be written in the Events.txt file
     */
    private void writeFile(Event event) {
        try {
            FileOutputStream out = openFileOutput("AllEvents.csv", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            osw.write(event.getId() + "," + event.getName() + "," + CalendarBuilder.SDF.format(event.getStartTime()) + ","
                    + CalendarBuilder.SDF.format(event.getEndTime()) + "," +
                    event.getSeriesName() + "," + event.getTag() + "," +event.getUserId()+"," + event.getInviteUser()+","+event.isConfirm());
            osw.write("\n");
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

    /**
     * write the data set of the list of events of the system into file Events.txt
     * @param events the list of events created and stored in the system
     */
    private void writeEventsToFile(List<Event> events) {
        try {
            FileOutputStream out = openFileOutput("AllEvents.csv", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for(Event event : events){
                osw.write(event.getId() + "," + event.getName() + "," + CalendarBuilder.SDF.format(event.getStartTime()) + ","
                        + CalendarBuilder.SDF.format(event.getEndTime()) + "," +
                        event.getSeriesName() + "," + event.getTag() + "," +event.getUserId() +"," + event.getInviteUser()+","+event.isConfirm());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }
}
