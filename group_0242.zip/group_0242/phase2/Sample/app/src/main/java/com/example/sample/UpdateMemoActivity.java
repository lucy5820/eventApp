package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.memo.Memo;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.List;

/**
 *  The UpdateMemotActivity is a screen of the calendar app's interface
 *  when update the data of memos
 */
public class UpdateMemoActivity extends AppCompatActivity {

    /**
     * memo and event id entered by the current login user
     */
    EditText memoText, eventId;
    Button update,delete,back;// Update Button, Delete Button, Back Button
    private User user;// the current login user
    private Memo memo;// memo

    @Override
    /**
     * Create all the static setup when creating the UpdateMemoActivity, including initialization parts:
     * inflate the UpdateMemoActivity's UI
     * interact with widges in UI. including Update Button, Delete Button, and Back Button
     * unbind data sets of users to get the information of the current user
     * * unbind data sets of memo to get the information of the corresponding memo
     * @param savedInstanceState a bundle containing the UpdateMemoActivity's previously frozen state
     */
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_memo);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
            memo = (Memo) bundle.getSerializable("memo");
            memo = CalendarFacade.getInstance().getMemo(memo.getId());
        }
        memoText = findViewById(R.id.memo);
        memoText.setText(memo.getContext());
        eventId = findViewById(R.id.ed_eventId);
        eventId.setText(memo.getEventId()+"");
        update = findViewById(R.id.update);
        delete = findViewById(R.id.btn_delete);
        back = findViewById(R.id.btn_back);
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // update the corresponding memo after clicking the Update Button, if succeed then
                //return to the MemoManageActivity
                //bind data sets of user to the list
                    if(!memoText.getText().toString().isEmpty()) {
                        if(!isInt( eventId.getText().toString().trim())) {
                            Toast.makeText(UpdateMemoActivity.this,"Event id should be number！",Toast.LENGTH_SHORT).show();
                        } else {
                            int id = Integer.parseInt(eventId.getText().toString().trim());
                            Event event = CalendarFacade.getInstance().getEventById(id);
                            if(event == null) {
                                Toast.makeText(UpdateMemoActivity.this,"Event not exist！",Toast.LENGTH_SHORT).show();
                            } else{
                                memo.setContext(memoText.getText().toString().trim());
                                memo.setEventId(id);
                                writeMemoToFile(CalendarFacade.getInstance().getMemos());
                                Toast.makeText(UpdateMemoActivity.this,"Update success！",Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(UpdateMemoActivity.this, MemoManageActivity.class);
                                Bundle bundle = new Bundle();
                                bundle.putSerializable("user", user);
                                intent.putExtras(bundle);
                                startActivity(intent);
                            }
                        }

                    }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //delete the corresponding memo after clicking the delete Button, if succeed then
                //return to the MemoManageActivity
                //bind data sets of user to the list
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateMemoActivity.this);
                builder.setTitle("Warnning:").setMessage("Are you sure delete this alert?").setIcon(R.drawable.icon_user).setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        CalendarFacade.getInstance().getMemos().remove(memo);
                        writeMemoToFile(CalendarFacade.getInstance().getMemos());
                        Intent intent = new Intent(UpdateMemoActivity.this, MemoManageActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("user", user);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     * write the corresponding memo in Memos.csv
     *
     * @param memos corresponding memo
     */
    private void writeMemoToFile(List<Memo> memos) {
        try {
            FileOutputStream out = openFileOutput("Memos.csv", Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for(Memo memo : memos) {
                osw.write(memo.getId()+","+memo.getContext() +","+memo.getEventId()+","+memo.getUserId());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

    /**
     * return true if the input is an integer, return false if the input is in the other form other than integer
     *
     * @param input input
     * @return whether the input is an integer or not
     */
    private boolean isInt(String input){
        try{
            Integer.parseInt(input);
        }catch (Exception e){
            return false;
        }
        return true;
    }
}
