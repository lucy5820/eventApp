package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.memo.Memo;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.Date;

/**
 * The LoginActivity is a screen of the calendar app's interface when users login to the app
 */
public class LoginActivity extends AppCompatActivity {


    /**
     * the username and password entered by the user
     */
    private EditText userName, passWord;

    private Button loginButton, registerButton; // The Login Button and Register Button

    /**
     * Create all the static setup when creating the LoginActivity, including initialization parts:
     * inflate the LoginActivity's UI
     * interact with widges in UI
     * bind data sets of users to the list
     * @param savedInstanceState a bundle containing the LoginActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        userName = findViewById(R.id.et_username);
        passWord = findViewById(R.id.et_password);
        loginButton = findViewById(R.id.btn_login);
        registerButton = findViewById(R.id.btn_register);
        getAllUsers();
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //transfer to MainActivity if login succeed
                //bind data sets of users to the list
                if(checkLogin()){
                    User user = CalendarFacade.getInstance().getUserByName(userName.getText().toString().trim());
                    CalendarFacade.getInstance().setUserId(user.getId());
                    getAllEvents();
                    getAllAlerts();
                    getAllMemos();
                    Intent intent = new Intent(LoginActivity.this,MainActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("user", user);
                    intent.putExtras(bundle);
                    startActivity(intent);
                } else {
                    Toast.makeText(LoginActivity.this,"Invalid username or password！",Toast.LENGTH_SHORT).show();
                }
            }
        });

        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //transfer to RegisterActivity
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });
    }

    /**
     * Check if the username input and its corresponding password input are valid
     * @return true if the username is valid, which means there exist such an user in the system;
     * false if the username input is empty or the password entered is empty or there doesn't exist
     * such a user with the input username in the system
     */
    private boolean checkLogin() {
        if(userName.getText().toString().isEmpty() || passWord.getText().toString().isEmpty()){
            return false;
        } else {
            if(CalendarFacade.getInstance().isUserExist(userName.getText().toString().trim())){
                return true;
            }
        }
        return false;
    }

    /**
     * Read the User.csv file of the system, and recreate the users of the system with the given
     * information read from the User.csv file, rebuilding list of users of the system with each
     * user's user names, corresponding passwords and id into the UserManager class
     */
    private void getAllUsers(){
        CalendarFacade.getInstance().userManager.removeAll();
        BufferedReader reader = null;
        try {
            FileInputStream in = openFileInput("Users.csv");
            reader = new BufferedReader(new InputStreamReader(in));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                String id = data[0];
                String username = data[1];
                String password = data[2];
                User user = new User(username,password,Integer.parseInt(id));
                CalendarFacade.getInstance().addUser(user);
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Read the Events.csv file of the system, and recreate the events of the system with the given
     * information read from the Events.csv file, rebuiding the list of events of the system, with
     * each event's id, event name, start date, end date, series name, tag, user id and invited user
     */
    private void getAllEvents(){
        CalendarFacade.getInstance().eventManager.removeAll();
        BufferedReader reader = null;
        try {
            FileInputStream in = openFileInput("AllEvents.csv");
            reader = new BufferedReader(new InputStreamReader(in));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                String name = data[1];
                Event event = new Event(name, id);
                event.setStartTime(CalendarBuilder.SDF.parse(data[2]));
                event.setEndTime(CalendarBuilder.SDF.parse(data[3]));
                if (!data[4].equals("null"))
                    event.setSeriesName(data[4]);
                if (!data[5].equals("null"))
                    event.setTag(data[5]);
                event.setUserId(Integer.parseInt(data[6]));
                event.setInviteUser(data[7]);
                event.setConfirm(Boolean.parseBoolean(data[8]));
                CalendarFacade.getInstance().addEvent(event);
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * Read the Alert.csv file of the system, and recreate the alerts of the system with the given
     * information read from the Alerts.csv file, rebuilding the list of alerts of the system, with
     * each alert's id and time
     */
    private void getAllAlerts(){
        BufferedReader reader = null;
        CalendarFacade.getInstance().alertManager.removeAll();
        try {
            FileInputStream in = openFileInput("Alerts.txt");
            reader = new BufferedReader(new InputStreamReader(in));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                Date time = CalendarBuilder.SDF.parse(data[1]);
                Alert alert = new Alert(time, id, Integer.parseInt(data[2]),Integer.parseInt(data[3]));
                CalendarFacade.getInstance().addAlert(alert);
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    /**
     * Read the Memos.csv file of the system, and recreate the memos of the system with the given
     * information read from the Memos.csv file, rebuilding the list of memos of the system
     */
    private void getAllMemos(){
        BufferedReader reader = null;
        CalendarFacade.getInstance().memoManager.removeAll();
        try {
            FileInputStream in = openFileInput("Memos.csv");
            reader = new BufferedReader(new InputStreamReader(in));
            String line;

            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                Memo memo = new Memo(Integer.parseInt(data[0]),data[1],Integer.parseInt(data[2]),Integer.parseInt(data[3]));
                CalendarFacade.getInstance().addMemo(memo);
            }
        }catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
