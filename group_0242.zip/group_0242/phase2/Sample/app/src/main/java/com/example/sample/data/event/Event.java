package com.example.sample.data.event;

import com.example.sample.data.user.User;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * an event in the calendar system
 */
public class Event implements Serializable {
    private String name;  // the name of the event
    private Date startTime;  // the start time of the event
    private Date endTime; // the end time of the event
    private String seriesName; // the series name of the event
    private String status; // the status of the event (Past, Ongoing or Future)
    private String tag; // the tag of the event
    private int id; // the id of the event
    private int userId;
    private String inviteUser;
    private boolean confirm;

    public boolean isConfirm() {
        return confirm;
    }

    public void setConfirm(boolean confirm) {
        this.confirm = confirm;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    /**
     * @param name the name of the event
     * @param id   the id of the event
     */
    public Event(String name, int id) {
        this.id = id;
        this.name = name;
        this.confirm = false;
    }

    public Event(String name,Date startTime,Date endTime,String seriesName,String tag,int userId){
        this.name = name;
        this.startTime = startTime;
        this.endTime = endTime;
        this.seriesName = seriesName;
        this.tag = tag;
        this.userId = userId;
        this.confirm = false;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the name of the event
     */
    public String getName() {
        return name;
    }

    /**
     * @return the id of the event
     */
    public int getId() {
        return this.id;
    }

    /**
     * @return the start time of the event
     */
    public Date getStartTime() {
        return startTime;
    }

    /**
     * set start time of the event
     *
     * @param startTime the start time assigned to the event
     */
    public void setStartTime(Date startTime) {
        this.startTime = startTime;
    }

    /**
     * @return the endTime of the event
     */
    public Date getEndTime() {
        return endTime;
    }

    /**
     * set the end time of the event
     *
     * @param endTime the end time assigned to the event
     */
    public void setEndTime(Date endTime) {
        this.endTime = endTime;
    }

    /**
     * @return the series name of the event
     */
    public String getSeriesName() {
        return seriesName;
    }

    /**
     * set the series name of the event
     *
     * @param seriesName the series name assigned to the event
     */
    public void setSeriesName(String seriesName) {
        this.seriesName = seriesName;
    }

    /**
     * @return the status of the event
     */
    public String getStatus() {
        return status;
    }

    /**
     * set the status of the event
     *
     * @param status the status of the event
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the tag of the event
     */
    public String getTag() {
        return tag;
    }

    /**
     * set the tag of the event
     *
     * @param tag the tag of the event
     */
    public void setTag(String tag) {
        this.tag = tag;
    }

    public void setInviteUser(String inviteUser) {
        this.inviteUser = inviteUser;
    }

    public String getInviteUser() {
        return inviteUser;
    }

    @Override
    public String toString() {
        String result = "Event" + " {" + "No." + id +
                ", name: " + name +
                ", startTime: " + CalendarBuilder.SDF.format(startTime) +
                ", endTime: " + CalendarBuilder.SDF.format(endTime);
        if (seriesName != null)
            result = result + ", series: " + seriesName;
        if (tag != null)
            result = result + ", tag: " + tag;
        return result + "}";
    }
}