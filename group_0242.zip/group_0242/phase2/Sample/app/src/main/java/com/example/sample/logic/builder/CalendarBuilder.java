package com.example.sample.logic.builder;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * the builder for Logic.CalendarFacade
 */
public class CalendarBuilder {
    public static final SimpleDateFormat SDF = new SimpleDateFormat("yyyy-MM-dd HH:mm"); // the format of time

    /**
     * Construct a calndar builder
     */
    public CalendarBuilder() {

    }

    /**
     * Construct a calender
     */
    public void constructCalender() {
        constructEvents();
        constructEventAlertMap();
        constructEventMemoMap();
        CalendarFacade.getInstance().updateEventStatus(new Date(), CalendarFacade.getInstance().getUserId());
    }

    /**
     * Construct all events created before by reading the Events.csv file
     */
    private void constructEvents() {
        File file = new File("src/files/Events.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                int id = Integer.parseInt(data[0]);
                String name = data[1];
                Event event = new Event(name, id);
                event.setStartTime(SDF.parse(data[2]));
                event.setEndTime(SDF.parse(data[3]));
                if (!data[4].equals("null"))
                    event.setSeriesName(data[4]);
                if (!data[5].equals("null"))
                    event.setTag(data[5]);
                CalendarFacade.getInstance().addEvent(event);
            }

        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException | ParseException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Construct the map which connect events and their associated alerts created before by
     * reading the EventAlertMap.csv file
     */
    private void constructEventAlertMap() {
        File file = new File("src/files/EventAlertMap.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                int eventId = Integer.parseInt(data[0]);
                int alertId = Integer.parseInt(data[1]);
                CalendarFacade.getInstance().addEventAlertConnection(eventId, alertId);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }



    /**
     * Construct the map which connect events and their associated memos created before by
     * reading the EventMemoMap.csv file
     */
    public void constructEventMemoMap() {
        File file = new File("src/files/EventMemoMap.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                String memo = data[0];
                int eventId = Integer.parseInt(data[1]);
                CalendarFacade.getInstance().addEventMemoConnection(memo, eventId);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * Construct the map which connect events and their associated memos created before by
     * reading the EventMemoMap.csv file
     */
    public void constructUserMap() {
        File file = new File("src/files/Users.csv");
        try {
            BufferedReader textFile = new BufferedReader(new FileReader(file));
            String line;

            while ((line = textFile.readLine()) != null) {
                String[] data = line.split(",");
                String id = data[0];
                String username = data[1];
                String password = data[2];
                int userId = Integer.parseInt(data[1]);
                User user = new User(username,password,Integer.parseInt(id));
                CalendarFacade.getInstance().addUser(user);
            }
        } catch (FileNotFoundException e) {
            System.out.println("File Not Found");
        } catch (IOException e) {
            System.out.println("Reading Error");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
