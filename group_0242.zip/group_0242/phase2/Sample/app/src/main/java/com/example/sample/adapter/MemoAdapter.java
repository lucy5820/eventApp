package com.example.sample.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.sample.R;
import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.memo.Memo;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * a Memo Adapter class connect the views of MemoAdapter and the underlying
 * memo data set
 */
public class MemoAdapter extends BaseAdapter {

    private Context context;

    private LayoutInflater layoutInflater;

    private List<Memo> memos = new ArrayList<>();

    HashMap<Integer, View> location = new HashMap<>();

    /**
     * Construct a Memo Adapter connecting the views of MemoAdapter and the underlying
     * memo data set which is the list of memos stored in the system
     * @param context: context containing the information views need
     */
    public MemoAdapter(Context context){
        this.context = context;
        layoutInflater = LayoutInflater.from(context);

    }

    /**
     * Get the number of memos in the memo data set represented by MemoAdapter
     * @return the number of memos in the Memo data set represented by MemoAdapter
     */
    @Override
    public int getCount() {
        return memos.size();
    }

    /**
     * Get the memo associated with the specified position in the memo data set
     * @return the memo associated with the specified position in the memo data set
     */
    @Override
    public Object getItem(int position) {
        return memos.get(position);
    }

    /**
     * Get the row id associated with the specified position in the memo data set
     * @return the row id associated with the specified position in the memo data set
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * set the memo data set with the input list of memos
     */
    public void setData(List<Memo> memos){
        this.memos = memos;
        notifyDataSetChanged();
    }

    /**
     * Get a view that displays the data at the specified position in the memo data set
     * @param position the position of the item within the adapter's data set
     * @param convertView the old view to reuse
     * @param parent the parent that this view will eventually be attached to
     * @return the view that displays the data at the specified position in the memo data set
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(location.get(position) == null) {
            convertView = layoutInflater.inflate(R.layout.layout_my_memo,null);
            Memo memo =(Memo) getItem(position);
            viewHolder = new ViewHolder(convertView,memo);
            location.put(position,convertView);
            convertView.setTag(viewHolder);
        } else{
            convertView = location.get(position);
            viewHolder = (ViewHolder) convertView.getTag();
        }
        return convertView;
    }

    /**
     * Construct a inner ViewHolder class to describe the memo view and metadata about its place
     */
    static class ViewHolder{
        TextView memoTextView,eventId;
        public ViewHolder(View viewItem, Memo memo){
            memoTextView = viewItem.findViewById(R.id.memo);
            memoTextView.setText(memo.getContext());
            eventId = viewItem.findViewById(R.id.eventId);
            eventId.setText(memo.getEventId()+"");
        }
    }

}
