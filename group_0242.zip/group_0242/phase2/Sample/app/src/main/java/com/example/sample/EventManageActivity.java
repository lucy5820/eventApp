package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.sample.adapter.AlertAdapter;
import com.example.sample.adapter.EventAdapter;
import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *  The EventManageActivity is a screen of the calendar app's interface
 *  when users' do operations about the management of events in the system
 */
public class EventManageActivity extends AppCompatActivity {

    private EditText searchEditText; // the text entered by the current user in the textBox

    private Button searchButton; //search Button on the screen

    private ListView eventsListView; // List view of memo

    private ImageButton addEventImageButton,filterButton, returnButton;

    private RadioGroup filterGroup;

    private User user; // current login user

    private EventAdapter eventAdapter; //An event Adapter

    private List<Event> myEvents = new ArrayList<>(); // a list stores events associate to the user


    /**
     * Create all the static setup when creating the MemoManageActivity, including initialization parts:
     * inflate the MemoManageActivity's UI
     * interact with widges in UI. including Search Button, Add ImageButton and BackImageButton
     * unbind data sets of users to get the information of the current user
     * @param savedInstanceState a bundle containing the MemoManageActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_manage);
        searchEditText = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.search_btn);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //search the event by clicking the Search Button
                if(!searchEditText.getText().toString().isEmpty()) {
                    eventAdapter = new EventAdapter(getApplicationContext());
                    myEvents = CalendarFacade.getInstance().getEventByName(searchEditText.getText().toString().trim(),user.getId());
                    myEvents.addAll(CalendarFacade.getInstance().getEventByTag(searchEditText.getText().toString().trim(),user.getId()));
                    myEvents.addAll(CalendarFacade.getInstance().getEventBySerires(searchEditText.getText().toString().trim(),user.getId()));
                    try{
                       Date date = CalendarBuilder.SDF.parse(searchEditText.getText().toString().trim());
                        myEvents.addAll(CalendarFacade.getInstance().getEventByDate(date,user.getId()));
                    }catch (ParseException e){

                    }
                    eventAdapter.setData(myEvents);
                    eventsListView.setAdapter(eventAdapter);
                }

            }
        });
        eventsListView = findViewById(R.id.lv_events);
        addEventImageButton = findViewById(R.id.ib_addEvent);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        eventAdapter = new EventAdapter(getApplicationContext());
        myEvents = CalendarFacade.getInstance().getAllEvents(user.getId());
        updateEventStatus(new Date(),myEvents);
        eventAdapter.setData(myEvents);
        eventsListView.setAdapter(eventAdapter);

        eventsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //bind data sets of user and memo to the list
                //transfer to UpdateMemoActivity after clicking it
                Event event = (Event) eventsListView.getAdapter().getItem(position);
                Bundle bundle = new Bundle();
                bundle.putSerializable("event",event);
                bundle.putSerializable("user",user);
                Intent intent = new Intent(EventManageActivity.this, UpdateEventActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        addEventImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EventManageActivity.this, AddEventActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        returnButton = findViewById(R.id.ib_back);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EventManageActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });
        filterButton = findViewById(R.id.ib_filter);
        final LayoutInflater inflater = this.getLayoutInflater();
        final Context context = this.getApplicationContext();
        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //select events according to past, current or future
                AlertDialog.Builder builder = new AlertDialog.Builder(EventManageActivity.this);
                builder.setTitle("Please select a time");
                //    set data to be shown on the list
                final String[] items = {"Past", "Now", "Future"};
                builder.setItems(items, new DialogInterface.OnClickListener()
                {
                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        eventAdapter = new EventAdapter(getApplicationContext());
                        List<Event> result = new ArrayList<>();
                        if(which == 0){
                            for (Event event : myEvents) {
                                if (event.getStatus().equals("Past")) {
                                    result.add(event);
                                }
                            }
                        } else if (which == 1){
                            for (Event event : myEvents) {
                                if (event.getStatus().equals("Ongoing")) {
                                    result.add(event);
                                }
                            }
                        } else if (which == 2){
                            for (Event event : myEvents) {
                                if (event.getStatus().equals("Future")) {
                                    result.add(event);
                                }
                            }
                        }
                        eventAdapter.setData(result);
                        eventsListView.setAdapter(eventAdapter);
                    }
                });
                builder.show();
            }
        });

        TextView tvRefresh = findViewById(R.id.tv_refresh);
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                eventAdapter = new EventAdapter(getApplicationContext());
                myEvents = CalendarFacade.getInstance().getAllEvents(user.getId());
                updateEventStatus(new Date(),myEvents);
                eventAdapter.setData(myEvents);
                eventsListView.setAdapter(eventAdapter);
            }
        });

    }

    /**
     * Check all events in the system associate to the user to update their status based on
     * current system time
     * @param now current time in the system
     * @param myEvents the list of events to check the status
     */
    public void updateEventStatus(Date now,List<Event> myEvents) {
        for (Event event : myEvents) {
            if (event.getStartTime().after(now)) {
                event.setStatus("Future");
                continue;
            }
            if (event.getEndTime().before(now)) {
                event.setStatus("Past");
            } else
                event.setStatus("Ongoing");
        }
    }


}
