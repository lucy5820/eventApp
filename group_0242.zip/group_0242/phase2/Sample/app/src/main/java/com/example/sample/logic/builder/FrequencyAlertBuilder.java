package com.example.sample.logic.builder;



import com.example.sample.data.alert.Alert;

import java.util.*;

/**
 * the builder for a series of alerts with frequency
 */
public class FrequencyAlertBuilder {
    private List<Alert> frequencyAlertList = new ArrayList<>(); // the series of alerts that would be created
    private String frequency; // the frequency of the series of alerts
    private Date endTime; // the end time of these series
    private int alertId; // the alertId assigned to alerts in this series

    /**
     * Construct a Logic.Builder.FrequencyAlertBuilder
     * @param id : the id associated with the alert to be created
     * @param endTime: the end time of the alert to be created
     */
    public FrequencyAlertBuilder(int id, Date endTime) {
        this.alertId = id;
        this.endTime = endTime;
    }


    /**
     * Add a certain time frequency to the start time of an alert so as to get the time that the alert should notify
     * next time
     * @param start : the current start time of the alert
     * @return : the next start time that the alert should notify user
     */
    private Date timeAdding(Date start){
        Calendar c = Calendar.getInstance();
        int hours = Integer.parseInt(frequency.split(",")[0]) * 24 +
                Integer.parseInt(frequency.split(",")[1]);
        c.setTime(start);
        c.add(Calendar.HOUR, hours);
        return c.getTime();
    }

    /**
     * Construct frequency alerts
     */
    public void constructFrequencyAlert(String frequency, int userId,int eventId) {
        Scanner in = new Scanner(System.in);
        Date now = new Date();
        Alert firstAlert = new Alert(now, alertId, userId,eventId);
        frequencyAlertList.add(firstAlert);
        this.frequency = frequency;

        Date currentEnd = timeAdding(now);

        while (currentEnd.compareTo(endTime) <= 0) {
            alertId++;
            Alert newAlert = new Alert(currentEnd, alertId, userId,eventId);
            currentEnd = timeAdding(currentEnd);
            frequencyAlertList.add(newAlert);
        }

        System.out.println("Construct series of alerts successfully!");
    }

    /**
     * Get the list of frequency alerts created
     * @return the list of frequency alerts associated with a certain event
     */
    public List<Alert> getFrequencyAlerts() {
        return frequencyAlertList;
    }

}
