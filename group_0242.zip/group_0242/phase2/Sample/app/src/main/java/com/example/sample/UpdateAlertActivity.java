package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.text.ParseException;
import java.util.List;

/**
 *  The UpdateAlertActivity is a screen of the calendar app's interface
 *  when update the data of alerts
 */
public class UpdateAlertActivity extends AppCompatActivity {

    /**
     *alert time and eventID entered by the current user
     */
    EditText alertTime, eventID;
    Button update,delete,back;// Update Button, Delete Button, Back Button
    private User user;// the current login user
    private Alert alert;//alert

    /**
     * Create all the static setup when creating the UpdateAlertActivity, including initialization parts:
     * inflate the UpdateAlertActivity's UI
     * interact with widges in UI. including Update Button, Delete Button, Back Button
     * unbind data sets of users to get the information of the current user
     * unbind data sets of alert to get the information of the alert
     * @param savedInstanceState a bundle containing the UpdateAlertActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
            alert = (Alert) bundle.getSerializable("alert");
            alert = CalendarFacade.getInstance().getAlertById(alert.getId());
        }
        setContentView(R.layout.activity_update_alert);
        alertTime = findViewById(R.id.ed_alertTime);
        eventID = findViewById(R.id.ed_eventId);
        update = findViewById(R.id.update);
        delete = findViewById(R.id.btn_delete);
        back = findViewById(R.id.btn_back);
        alertTime.setText(CalendarBuilder.SDF.format(alert.getTime()));
        eventID.setText(alert.getEventId()+"");
        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // update the alert after clicking the Update button
                // return to the previous Activity
                if(checkUpdate()) {
                    try {
                        alert.setTime(CalendarBuilder.SDF.parse(alertTime.getText().toString().trim()));
                        alert.setEventId(Integer.parseInt(eventID.getText().toString().trim()));
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                    writeAlertsToFile(CalendarFacade.getInstance().getAllAlerts());
                    Toast.makeText(UpdateAlertActivity.this,"Update success！",Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // delete the corresponding alert after clicking Delete Button
                // return to AlertManageActivity if succeed
                // bind data sets of users to the list
                AlertDialog.Builder builder = new AlertDialog.Builder(UpdateAlertActivity.this);
                builder.setTitle("Warnning:").setMessage("Are you sure delete this alert?").setIcon(R.drawable.icon_user).setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        CalendarFacade.getInstance().getAllAlerts().remove(alert);
                        writeAlertsToFile(CalendarFacade.getInstance().getAllAlerts());
                        Intent intent = new Intent(UpdateAlertActivity.this, AlertManageActivity.class);
                        Bundle bundle = new Bundle();
                        bundle.putSerializable("user", user);
                        intent.putExtras(bundle);
                        startActivity(intent);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     * return true if the corresponding alert is valid, vice versa
     *
     * @return whether the updated alert is valid or not
     */
    private boolean checkUpdate() {
        if(alertTime.getText().toString().isEmpty() || eventID.getText().toString().isEmpty()) {
            Toast.makeText(UpdateAlertActivity.this,"Can not empty！",Toast.LENGTH_SHORT).show();
            return false;
        } else {
            if(!isValidTime(alertTime.getText().toString().trim())) {
                Toast.makeText(UpdateAlertActivity.this,"Date format yyyy-MM-dd HH:mm！",Toast.LENGTH_SHORT).show();
                return false;
            }
            if(!isInt(eventID.getText().toString().trim())) {
                Toast.makeText(UpdateAlertActivity.this,"Event id should be number！",Toast.LENGTH_SHORT).show();
                return false;
            } else {
                int eventId = Integer.parseInt(eventID.getText().toString().trim());
                Event event = CalendarFacade.getInstance().getEventById(eventId);
                if(event == null) {
                    Toast.makeText(UpdateAlertActivity.this,"Event not exist！",Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * return true if the String time is in the correct time form and vice versa
     *
     * @param time time
     * @return whether the String time is in the correct time form or not
     */
    private boolean isValidTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * return true if the input is an integer, and return false if the input is in other form than
     * integer
     *
     * @param input input
     * @return whether the input is an integer or not
     */
    private boolean isInt(String input){
        try{
            Integer.parseInt(input);
        }catch (Exception e){
            return false;
        }
        return true;
    }

    /**
     * write corresponding alerts in Alerts.txt
     *
     * @param alerts corresponding alerts
     */
    private void writeAlertsToFile(List<Alert> alerts) {
        try {
            FileOutputStream out = openFileOutput("Alerts.txt", Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for (Alert alert : alerts) {
                osw.write(alert.getId() + "," + CalendarBuilder.SDF.format(alert.getTime()) + "," + alert.getUserId() + "," + alert.getEventId());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }
}
