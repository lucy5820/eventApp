package com.example.sample.logic.builder;

import com.example.sample.data.user.User;

public class UserBuilder {

    private User user;

    private int userId;

    public UserBuilder(int id) {
        this.userId = id;
    }

    public User getUser() {
        return user;
    }

    public void constructUser(String name, String password) {
        user = new User(name,password,userId);
    }
}
