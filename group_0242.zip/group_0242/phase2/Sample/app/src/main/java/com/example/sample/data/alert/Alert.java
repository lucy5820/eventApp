package com.example.sample.data.alert;

import com.example.sample.logic.builder.CalendarBuilder;

import java.io.Serializable;
import java.util.Date;

/**
 * an alert in the calendar system
 */
public class Alert implements Serializable {
    private Date time; // the time of the alert
    private int id; // the id of the alert
    private int userId;
    private int eventId;

    /**
     * Construct a Data.Data.Managers.Items.Alert for an event
     * @param time: the time that this alert need to start to ring
     * @param id:   the identifier for a certain alert
     */
    public Alert(Date time, int id, int userId,int eventId) {
        this.id = id;
        this.time = time;
        this.userId = userId;
        this.eventId = eventId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getUserId() {
        return userId;
    }

    public void setId(int id) {
        this.id = id;
    }

    /**
     * get the time that the alert should ring
     *
     * @return the time that the alert should ring
     */
    public Date getTime() {
        return time;
    }


    public void setTime(Date time) {
        this.time = time;
    }

    /**
     * get the int representation of identity of a certain alert
     * @return: the int representation of identity of a certain alert
     */
    public int getId() {
        return this.id;
    }

    @Override
    public String toString() {
        return "Alert{" +
                "time: " + CalendarBuilder.SDF.format(time) +
                '}';
    }

}