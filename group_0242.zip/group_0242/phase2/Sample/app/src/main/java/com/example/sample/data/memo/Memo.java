package com.example.sample.data.memo;

import java.io.Serializable;

public class Memo implements Serializable {

    private int id;

    private String context;

    private int eventId;

    private int userId;

    public Memo(int id, String context,int eventId,int userId) {
        this.id  = id;
        this.context = context;
        this.eventId = eventId;
        this.userId = userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }

    public void setEventId(int eventId) {
        this.eventId = eventId;
    }

    public int getEventId() {
        return eventId;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public String getContext() {
        return context;
    }

    public void setContext(String context) {
        this.context = context;
    }
}
