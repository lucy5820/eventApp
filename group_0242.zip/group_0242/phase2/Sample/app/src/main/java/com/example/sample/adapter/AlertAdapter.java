package com.example.sample.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.sample.R;
import com.example.sample.data.alert.Alert;
import com.example.sample.logic.builder.CalendarBuilder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class AlertAdapter extends BaseAdapter {

    private Context context;

    private LayoutInflater layoutInflater;

    private List<Alert> alerts = new ArrayList<>();

    HashMap<Integer, View> location = new HashMap<>();

    /**
     * Construct an AlertAdapter connecting the views of AlertAdapter and the underlying
     * Alert data set which is the list of Alerts stored in system
     * @param context: context containing the information views need
     */
    public AlertAdapter(Context context){
        this.context = context;
        layoutInflater = LayoutInflater.from(context);

    }

    /**
     * Get the number of alerts in the Alert data set represented by AlertAdapter
     * @return the number of alerts in the Alert data set represented by AlertAdapter
     */
    @Override
    public int getCount() {
        return alerts.size();
    }

    /**
     * Get the alert associated with the specified position in the Alert data set
     * @return the alert associated with the specified position in the Alert data set
     */
    @Override
    public Object getItem(int position) {
        return alerts.get(position);
    }

    /**
     * Get the row id associated with the specified position in the Alert data set
     * @return the row id associated with the specified position in the Alert data set
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * set the Alert data set with the input list of alerts
     */
    public void setData(List<Alert> alerts){
        this.alerts = alerts;
        notifyDataSetChanged();
    }

    /**
     * Get a view that displays the data at the specified position in the Alert data set
     * @param position the position of the item within the adapter's data set
     * @param convertView the old view to reuse
     * @param parent the parent that this view will eventually be attached to
     * @return the view that displays the data at the specified position in the Alert data set
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(location.get(position) == null) {
            convertView = layoutInflater.inflate(R.layout.layout_my_alert,null);
            Alert alert =(Alert) getItem(position);
            viewHolder = new ViewHolder(convertView,alert);
            location.put(position,convertView);
            convertView.setTag(viewHolder);
        } else{
            convertView = location.get(position);
            viewHolder = (ViewHolder) convertView.getTag();
        }
        return convertView;
    }

    /**
     * Construct a inner ViewHolder class to describe the alert view and metadata about its place
     */
    static class ViewHolder{
        TextView alertId, time, eventId;
        public ViewHolder(View viewItem, Alert alert){
            alertId = viewItem.findViewById(R.id.alert_id);
            time = viewItem.findViewById(R.id.time);
            alertId.setText(alert.getId()+"");
            time.setText(CalendarBuilder.SDF.format(alert.getTime()));
        }
    }
}
