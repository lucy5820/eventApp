package com.example.sample.logic;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.alert.AlertManager;
import com.example.sample.data.event.Event;
import com.example.sample.data.event.EventManager;
import com.example.sample.data.map.EventAlertMap;
import com.example.sample.data.map.EventMemoMap;
import com.example.sample.data.memo.Memo;
import com.example.sample.data.memo.MemoManager;
import com.example.sample.data.user.User;
import com.example.sample.data.user.UserManager;


import java.util.*;

/**
 * a class that contains six subsystems and this class is used to deal with all the things about the calendar system
 */
public class CalendarFacade implements Observer {

    private static CalendarFacade instance = new CalendarFacade();
    public EventManager eventManager; // the eventManager to be constructed in the Logic.CalendarFacade
    public AlertManager alertManager; // the alertManager to be constructed in the Logic.CalendarFacade
    public MemoManager memoManager;// the memoManager to be constructed in the Logic.CalendarFacade
    public EventAlertMap eventAlertMap; // the event alert map to be constructed in the Logic.CalendarFacade
    public EventMemoMap eventMemoMap; // the event memo map to be constructed in the Logic.CalendarFacade
    public StatusController statusController; // the status controller to be constructed in the Logic.CalendarFacade
    public UserManager userManager;
    private int userId;

    /**
     * Construct a Logic.CalendarFacade
     */
    private CalendarFacade() {
        eventManager = new EventManager();
        alertManager = new AlertManager();
        memoManager = new MemoManager();
        userManager = new UserManager();
        eventAlertMap = new EventAlertMap(eventManager, alertManager);
        eventMemoMap = new EventMemoMap(eventManager);
        statusController = new StatusController(eventManager, alertManager);
    }

    public static CalendarFacade getInstance(){
        return  instance;
    }

    /**
     * Update status of events and arose alerts when receiving the notification about time change from the clock
     * @param o : the subject observed by calender facade, which is clock in this case
     * @param arg: the time of clock that clock will notify its observer
     */
    @Override
    public void update(Observable o, Object arg) {
        Date now = (Date) arg;
        statusController.updateEventStatus(now,userId);
        statusController.arouseAlert(now);
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public int getUserId() {
        return userId;
    }

    public Map<Integer, List<Integer>> getConnection() {
        return eventAlertMap.getConnection();
    }

    public Map<String, List<Integer>> getMemoConnection() {
        return eventMemoMap.getConnection();
    }

    /**
     * Add observer to calendarFacade
     * @param o : the observer to be added to observe calendar facade, which is main menu in this case
     */
    public void addObserverToStatusController(Observer o) {
        statusController.addObserver(o);
    }

    /**
     * Get the maximum id of events in the system
     * @return the maximum id of current existing events in the system
     */
    public int getEventMaxId() {
        return eventManager.getMaxId();
    }

    /**
     * Get a certain event by its id
     * @param id the id associated with the event that needs to be found
     * @return: the event that the user needs to get
     */
    public Event getEventById(int id) {
        return eventManager.getEventById(id);
    }

    public User getUserById(int id){
        return  userManager.getUserById(id);
    }

    public int getUserMaxId(){
        return  userManager.getMaxId();
    }
    /**
     * Get the maximum id of alerts in the system
     * @return the maximum id of current existing alerts in the system
     */
    public int getAlertMaxId() {
        return alertManager.getMaxId();
    }

    public int getMemoMaxId() {
        return memoManager.getMaxId();
    }


    /**
     * Add an event to the system
     * @param event the event that needs to be added
     */
    public void addEvent(Event event) {
        eventManager.addEvent(event);
    }

    /**
     * Add an alert to the system
     * @param alert the memo that needs to be added
     */
    public void addAlert(Alert alert) {
        alertManager.addAlert(alert);
    }

    /**
     * Add a memo to the system
     * @param memo the memo that needs to be added
     */
    public void addMemo(Memo memo) {
        memoManager.addMemo(memo);
    }

    public Memo getMemo(int id) {
        return memoManager.getMemoById(id);
    }
    /**
     * add a connection between an event and a alert to the map
     * @param event the event to be added to the map
     * @param alert the alert associated with the given event that will be added to the map
     */
    public void addEventAlertConnection(Event event, Alert alert) {
        eventAlertMap.addConnection(event, alert);
    }

    /**
     * add a connection between an event and a alert to the map
     * @param event the event to be added to the map
     * @param memo the memo associated with the given event that will be added to the map
     */
    public void addEventMemoConnection(Event event, String memo) {
        eventMemoMap.addConnection(memo, event);
    }

    /**
     * add a connection between an event and a alert to the map
     * @param eventId the id of event to be added to the map
     * @param alertId the id of alert associated with the given event that will be added to the map
     */
    public void addEventAlertConnection(int eventId, int alertId)  {
        eventAlertMap.addConnection(eventId, alertId);
    }

    /**
     * Get a list of alerts associated with a given event
     * @param event : the input event which needs to find its associated alerts
     * @return: the list of alerts associated with the given event
     */
    public List<Alert> getRelatedAlerts(Event event) {
        return eventAlertMap.getRelatedAlerts(event);
    }

    /**
     * Get an event associated with a given alert
     * @param alert : the alert which needs to find its associated event
     * @return the event associated to the given alert
     */
    public Event getRelatedEvent(Alert alert) {
        return eventAlertMap.getRelatedEvent(alert);
    }

    /**
     * add a connection between an event and a memo to the map
     * @param memo the memo to be added to the map
     * @param eventId the id of event associated with the given memo that will be added to the map
     */
    public void addEventMemoConnection(String memo, int eventId) {
        eventMemoMap.addConnection(memo, eventId);
    }

    /**
     * Get a list of events associated with a given memo
     * @param memo the memo whose associated events need to be found
     * @return the list of events that associated with the given memo
     */
    public List<Event> getRelatedEvents(String memo) {
        return eventMemoMap.getRelatedEvents(memo);
    }

    /**
     * Get the memo associated with a given event
     * @param event : the input event which needs to find its associated memo
     * @return: the memo associated to the given event
     */
    public String getRelatedMemo(Event event) {
        return eventMemoMap.getRelatedMemo(event);
    }

    /**
     * Get all memos stored in the system
     * @return the list of all memos in the system
     */
    public List<Memo> getMemos() {
        return memoManager.getMemos();
    }

    public List<Memo> getMemos(int userId) {
        return memoManager.getMyMemos(userId);
    }

    /**
     * Get all events stored in the system
     * @return the list of all events in the system
     */
    public List<Event> getAllEvents(int userId) {
        return eventManager.getAllEvents(userId);
    }

    public List<Event> getInviteEvents(int userId) {
        return eventManager.getInviteEvents(userId);
    }

    /**
     * Get all events stored in the system
     * @return the list of all events in the system
     */
    public List<Event> getSystemAllEvents() {
        return eventManager.getAllEvents();
    }

    /**
     * Get all past events stored in the system
     * @return the list of all past events in the system
     */
    public List<Event> getPastEvents(int userId) {
        return eventManager.getPastEvents(userId);
    }

    /**
     * Get all ongoing events stored in the system
     * @return the list of all ongoing events in the system
     */
    public List<Event> getOngoingEvents(int userId) {
        return eventManager.getOngoingEvents(userId);
    }

    /**
     * Get all future events stored in the system
     * @return the list of all future events in the system
     */
    public List<Event> getFutureEvents(int userId) {
        return eventManager.getFutureEvents(userId);
    }

    /**
     * Get all events associated to given series in the system
     * @return the list of all events associated with given series in the system
     */
    public List<Event> getEventBySerires(String series, int userId) {
        return eventManager.getEventBySerires(series, userId);
    }

    /**
     * Get events with a given name in the system
     * @return the events associated with a given name in the system
     */
    public List<Event> getEventByName(String name,int userId) {
        return eventManager.getEventByName(name,userId);
    }

    /**
     * Get all events with a given tag in the system
     * @return the list of events associated with a given tag in the system
     */
    public List<Event> getEventByTag(String tag,int userId) {
        return eventManager.getEventByTag(tag,userId);
    }

    /**
     * Get all events associated with a given date in the system
     * @return the list of all events associated with a given date in the system
     */
    public List<Event> getEventByDate(Date date,int userId) {
        return eventManager.getEventByDate(date,userId);
    }

    /**
     * Get all alerts stored in the system
     * @return the list of all alerts in the system
     */
    public List<Alert> getAllAlerts() {
        return alertManager.getAllAlert();
    }

    /**
     * Get all alerts stored in the system
     * @return the list of all alerts in the system
     */
    public List<Alert> getAllAlerts(int userId) {
        return alertManager.getAllAlert(userId);
    }


    /**
     * Update all events' status stored in the system
     * @param now the current time
     */
    public void updateEventStatus(Date now,int userId) {
        statusController.updateEventStatus(now,userId);
    }

    public void addUser(User user){
        userManager.addUser(user);
    }

    public List<User> getAllUser() {
        return userManager.getAllUsers();
    }

    public boolean isUserExist(String userName) {
        return userManager.isExist(userName);
    }

    public User getUserByName(String userName){
        return  userManager.getUserByName(userName);
    }

    public Alert getAlertById(int id) {
        return alertManager.getAlertById(id);
    }

}
