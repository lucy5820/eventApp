package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import com.example.sample.data.user.User;


/**
 * The Main Activity in the program
 */
public class MainActivity extends AppCompatActivity {

    /**
     * Event Button, Alert Button, Memo Button and Log out Button
     */
    Button eventManageButton, alertManageButton, memoManageButton, logoutButton,inviteButton;
    private User user;// the login user

    /**
     * Create all the static setup when creating the MainActivity, including initialization parts:
     * inflate the MainActivity's UI
     * interact with widges in UI. including Event Button, Alert Button, Memo Button, Log out Button
     * unbind data sets of users to get the information of the current user
     * bind data sets of users to the list
     * @param savedInstanceState a bundle containing the MainActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eventManageButton = findViewById(R.id.btn_event);
        alertManageButton = findViewById(R.id.btn_alert);
        memoManageButton = findViewById(R.id.btn_memo);
        logoutButton = findViewById(R.id.btn_logout);
        inviteButton = findViewById(R.id.btn_invite);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        eventManageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // transfer to EventManageActivity
                Intent intent = new Intent(MainActivity.this, EventManageActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        alertManageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // transfer to AlertManageActivity
                Intent intent = new Intent(MainActivity.this, AlertManageActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        memoManageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //transfer to MemoManageActivity
                Intent intent = new Intent(MainActivity.this, MemoManageActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        logoutButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //transfer to LoginActivity
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Warnning:").setMessage("Are you sure logout?").setIcon(R.drawable.icon_user).setPositiveButton("Sure", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        Intent intent = new Intent(getApplicationContext(),LoginActivity.class);
                        startActivity(intent);
                    }
                }).setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                }).show();
            }
        });

        inviteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //transfer to InviteActivity
                Intent intent = new Intent(MainActivity.this, InviteActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
    }
}
