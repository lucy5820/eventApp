package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.sample.adapter.AlertAdapter;
import com.example.sample.adapter.MemoAdapter;
import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.memo.Memo;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *  The MemoManageActivity is a screen of the calendar app's interface
 *  when users' do operations about the management of memos in the system
 */
public class MemoManageActivity extends AppCompatActivity {

    private EditText searchEditText;// the text entered by the current user in the textBox

    private Button searchButton;//search Button on the screen

    private ListView memosListView;// List view of memo

    private MemoAdapter memoAdapter;//A memo Adapter

    private List<Memo> memos = new ArrayList<>();// a list stores all memos

    private ImageButton addMemoImageButton, returnButton;//Image Button for add and return

    private User user;// current login user

    /**
     * Create all the static setup when creating the MemoManageActivity, including initialization parts:
     * inflate the MemoManageActivity's UI
     * interact with widges in UI. including Search Button, Add ImageButton and BackImageButton
     * unbind data sets of users to get the information of the current user
     * @param savedInstanceState a bundle containing the MemoManageActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memo_manage);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        searchEditText = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.search_btn);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //search the memo by clicking the Search Button
                if(!searchEditText.getText().toString().isEmpty()){
                    List<Memo> searchMemos = new ArrayList<>();
                    for(Memo memo : memos) {
                        if(memo.getContext().equals(searchEditText.getText().toString().trim())){
                            searchMemos.add(memo);
                        }
                    }
                    if(isInt(searchEditText.getText().toString().trim())){
                        int eventId = Integer.parseInt(searchEditText.getText().toString().trim());
                        for(Memo memo : memos) {
                            if(memo.getEventId() == eventId){
                                searchMemos.add(memo);
                            }
                        }
                    }
                    memoAdapter = new MemoAdapter(getApplicationContext());
                    memoAdapter.setData(searchMemos);
                    memosListView.setAdapter(memoAdapter);
                }

            }
        });
        memosListView = findViewById(R.id.lv_memos);
        addMemoImageButton = findViewById(R.id.ib_addMemo);
        addMemoImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // add memo after clicking the Add ImageButton and transfer to AddMemoActivity
                // bind data sets of user to the list
                Intent intent = new Intent(MemoManageActivity.this, AddMemoActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user",user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        memoAdapter = new MemoAdapter(getApplicationContext());
        memos = CalendarFacade.getInstance().getMemos(user.getId());
        memoAdapter.setData(memos);
        memosListView.setAdapter(memoAdapter);
        memosListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //bind data sets of user and memo to the list
                //transfer to UpdateMemoActivity after clicking it
                Memo memo = (Memo) memosListView.getAdapter().getItem(position);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user",user);
                bundle.putSerializable("memo",memo);
                Intent intent = new Intent(MemoManageActivity.this, UpdateMemoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        returnButton = findViewById(R.id.ib_back);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //return to MainActivity after clicking Back ImageButton
                //bind data sets of user to the list
                Intent intent = new Intent(MemoManageActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });

        TextView tvRefresh = findViewById(R.id.tv_refresh);
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // refresh this activity
                memoAdapter = new MemoAdapter(getApplicationContext());
                memos = CalendarFacade.getInstance().getMemos(user.getId());
                memoAdapter.setData(memos);
                memosListView.setAdapter(memoAdapter);
            }
        });
    }

    /**
     * return true is input is an integer, return false if the input is in other form other than integer
     *
     * @param input input
     * @return whether the input is an integer or not
     */
    private boolean isInt(String input){
        try{
            Integer.parseInt(input);
        }catch (Exception e){
            return false;
        }
        return true;
    }
}
