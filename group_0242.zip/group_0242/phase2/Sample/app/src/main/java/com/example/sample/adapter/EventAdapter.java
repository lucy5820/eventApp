package com.example.sample.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;
import com.example.sample.R;
import com.example.sample.data.event.Event;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EventAdapter extends BaseAdapter {

    private Context context;

    private LayoutInflater layoutInflater;

    private List<Event> events = new ArrayList<>();

    HashMap<Integer,View> location = new HashMap<>();

    /**
     * Construct an EventAdapter connecting the views of EventAdapter and the underlying
     * Event data set which is the list of Events stored in system
     * @param context: context containing the information views need
     */
    public EventAdapter(Context context){
        this.context = context;
        layoutInflater = LayoutInflater.from(context);

    }

    /**
     * Get the number of events in the Event data set represented by EventAdapter
     * @return the number of events in the Event data set represented by EventAdapter
     */
    @Override
    public int getCount() {
        return events.size();
    }

    /**
     * Get the event associated with the specified position in the Event data set
     * @return the event associated with the specified position in the Event data set
     */
    @Override
    public Object getItem(int position) {
        return events.get(position);
    }

    /**
     * Get the row id associated with the specified position in the Event data set
     * @return the row id associated with the specified position in the Event data set
     */
    @Override
    public long getItemId(int position) {
        return position;
    }

    /**
     * set the Event data set with the input list of events
     */
    public void setData(List<Event> events){
        this.events = events;
        notifyDataSetChanged();
    }

    /**
     * Get a view that displays the data at the specified position in the Event data set
     * @param position the position of the item within the adapter's data set
     * @param convertView the old view to reuse
     * @param parent the parent that this view will eventually be attached to
     * @return the view that displays the data at the specified position in the Event data set
     */
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder = null;
        if(location.get(position) == null) {
            convertView = layoutInflater.inflate(R.layout.layout_my_event,null);
            Event event =(Event) getItem(position);
            viewHolder = new ViewHolder(convertView,event);
            location.put(position,convertView);
            convertView.setTag(viewHolder);
        } else{
            convertView = location.get(position);
            viewHolder = (ViewHolder) convertView.getTag();
        }
        return convertView;
    }

    /**
     * Construct a inner ViewHolder class to describe the event view and metadata about its place
     */
    static class ViewHolder{
        TextView eventId, status, tag, series;
        public ViewHolder(View viewItem, Event event){
            eventId = viewItem.findViewById(R.id.event_id);
            status = viewItem.findViewById(R.id.event_status);
            tag = viewItem.findViewById(R.id.tag);
            series = viewItem.findViewById(R.id.series);
            eventId.setText(event.getId()+"");
            status.setText(event.getStatus());
            tag.setText(event.getTag());
            series.setText(event.getSeriesName());
        }
    }
}
