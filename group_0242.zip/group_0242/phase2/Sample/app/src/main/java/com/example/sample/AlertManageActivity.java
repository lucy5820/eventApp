package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;
import android.widget.TextView;

import com.example.sample.adapter.AlertAdapter;
import com.example.sample.adapter.EventAdapter;
import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *  The AlertManageActivity is a screen of the calendar app's interface
 *  when users' do operations about the management of alerts in the system
 */
public class AlertManageActivity extends AppCompatActivity {

    private EditText searchEditText; // the text entered by the current user in the textBox

    private Button searchButton; //search Button on the screen

    private ListView alertsListView; // List view of alerts

    private AlertAdapter alertAdapter; //A alert Adapter

    private List<Alert> alerts = new ArrayList<>(); // a list stores all alerts

    private User user; // current login user

    private ImageButton addAlertImageButton,filterButton, returnButton;

    /**
     * Create all the static setup when creating the AlertManageActivity, including initialization parts:
     * inflate the AlertManageActivity's UI
     * interact with widges in UI. including Search Button, Add ImageButton and BackImageButton
     * unbind data sets of users to get the information of the current user
     * @param savedInstanceState a bundle containing the AlertManageActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        setContentView(R.layout.activity_alert_manage);
        searchEditText = findViewById(R.id.searchInput);
        searchButton = findViewById(R.id.search_btn);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //search the alert by clicking the Search Button
                if(!searchEditText.getText().toString().isEmpty() && isInt(searchEditText.getText().toString().trim())){
                    int eventId = Integer.parseInt(searchEditText.getText().toString().trim());
                    List<Alert> eventAlerts = new ArrayList<>();
                    for(Alert alert : alerts) {
                        if(alert.getEventId() == eventId) {
                            eventAlerts.add(alert);
                        }
                    }
                    alertAdapter = new AlertAdapter(getApplicationContext());
                    alerts = eventAlerts;
                    alertAdapter.setData(alerts);
                    alertsListView.setAdapter(alertAdapter);
                }
            }
        });
        alertsListView = findViewById(R.id.lv_alerts);
        addAlertImageButton = findViewById(R.id.ib_addAlert);
        alerts = CalendarFacade.getInstance().getAllAlerts(user.getId());
        alertAdapter = new AlertAdapter(getApplicationContext());
        alertAdapter.setData(alerts);
        alertsListView.setAdapter(alertAdapter);
        alertsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Alert alert = (Alert) alertsListView.getAdapter().getItem(position);
                Bundle bundle = new Bundle();
                bundle.putSerializable("alert",alert);
                bundle.putSerializable("user",user);
                Intent intent = new Intent(AlertManageActivity.this, UpdateAlertActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        addAlertImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlertManageActivity.this, AddAlertActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });
        filterButton = findViewById(R.id.ib_filter);
        filterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        returnButton = findViewById(R.id.ib_back);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AlertManageActivity.this, MainActivity.class);
                Bundle bundle = new Bundle();
                bundle.putSerializable("user", user);
                intent.putExtras(bundle);
                startActivity(intent);

            }
        });

        TextView tvRefresh = findViewById(R.id.tv_refresh);
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertAdapter = new AlertAdapter(getApplicationContext());
                alerts = CalendarFacade.getInstance().getAllAlerts(user.getId());
                alertAdapter.setData(alerts);
                alertsListView.setAdapter(alertAdapter);
            }
        });
    }

    /**
     * return true is input is an integer, return false if the input is in other form other than integer
     *
     * @param input input
     * @return whether the input is an integer or not
     */
    private boolean isInt(String input){
        try{
            Integer.parseInt(input);
        }catch (Exception e){
            return false;
        }
        return true;
    }

}
