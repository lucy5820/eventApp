package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;

/**
 *  The ConfirmInviteActivity is a screen of the calendar app's interface
 *  when a user receives a invitation from another user about a certain event
 */
public class ConfirmInviteActivity extends AppCompatActivity {

    TextView eventName, startTime, endTime, series, tag, inviteStatus;
    private Event event;
    private User user;
    Button confirmButton,cancelButton,backButton;

    /**
     * Create all the static setup when creating the ConfirmInviteActivity,
     * including initialization parts:
     * inflate the ConfirmInviteActivity's UI
     * interact with widges in UI. including Search Button, Add ImageButton and BackImageButton
     * unbind data sets of users to get the information of the current user
     * @param savedInstanceState a bundle containing the AlertManageActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirm_invite);
        eventName = findViewById(R.id.tv_eventName);
        startTime = findViewById(R.id.tv_startTime);
        endTime = findViewById(R.id.tv_endTime);
        series = findViewById(R.id.tv_series);
        inviteStatus = findViewById(R.id.tv_status);
        tag = findViewById(R.id.tv_tag);
        confirmButton = findViewById(R.id.confirm);
        cancelButton = findViewById(R.id.btn_cancel);
        backButton = findViewById(R.id.btn_back);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
            event = (Event) bundle.getSerializable("event");
            event = CalendarFacade.getInstance().getEventById(event.getId());
        }
        eventName.setText(event.getName());
        startTime.setText(CalendarBuilder.SDF.format(event.getStartTime()));
        endTime.setText(CalendarBuilder.SDF.format(event.getEndTime()));
        series.setText(event.getSeriesName());
        inviteStatus.setText(event.isConfirm() == false ? "False" : "True");
        tag.setText(event.getTag());

        confirmButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                event.setConfirm(true);
                writeEventsToFile(CalendarFacade.getInstance().getSystemAllEvents());
                finish();
            }
        });
        cancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                event.setInviteUser(null);
                writeEventsToFile(CalendarFacade.getInstance().getSystemAllEvents());
                finish();
            }
        });


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    /**
     * write the data set of the list of all events of the system into file AllEvents.csv
     * @param events the list of events created and stored in the system
     */
    private void writeEventsToFile(List<Event> events) {
        try {
            FileOutputStream out = openFileOutput("AllEvents.csv", Context.MODE_PRIVATE);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for(Event event : events){
                osw.write(event.getId() + "," + event.getName() + "," + CalendarBuilder.SDF.format(event.getStartTime()) + ","
                        + CalendarBuilder.SDF.format(event.getEndTime()) + "," +
                        event.getSeriesName() + "," + event.getTag() + "," +event.getUserId() + "," + event.getInviteUser()+","+event.isConfirm());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }
}
