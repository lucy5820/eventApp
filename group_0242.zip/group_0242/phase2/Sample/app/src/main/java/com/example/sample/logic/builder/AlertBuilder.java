package com.example.sample.logic.builder;

import com.example.sample.data.alert.Alert;
import java.text.ParseException;
import java.util.Date;

/**
 * a builder for Alert
 */
public class AlertBuilder {
    private Alert alert; // an alert that would be constructed
    private int alertId;  // the id of the alert that would be constructed

    /**
     * Construct an AlertBuilder
     *
     * @param id: the value of id that will be associated with the alert to be created
     */
    public AlertBuilder(int id) {
        alertId = id;
    }

    /**
     * Get the alert created by the AlertBuilder
     * @return: the alert created
     */
    public Alert getAlert() {
        return this.alert;
    }



    /**
     * Construct an Data.Data.Managers.Items.Alert according to information provided by user, which is typed into the system
     * @throws ParseException: the string cannot be parsed
     */
    public void constructAlert(String time, int userId, int eventId) {
        Date date = null;
        try {
            date = CalendarBuilder.SDF.parse(time);
            alert = new Alert(date, alertId, userId, eventId);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
