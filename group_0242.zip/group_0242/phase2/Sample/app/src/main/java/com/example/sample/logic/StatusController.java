package com.example.sample.logic;


import com.example.sample.data.alert.Alert;
import com.example.sample.data.alert.AlertManager;
import com.example.sample.data.event.Event;
import com.example.sample.data.event.EventManager;

import java.util.*;

/**
 * the class is responsible for updating information about events and alerts when it is notified
 */
public class StatusController extends Observable {
    private AlertManager alertManager; // the alert manager to be created
    private EventManager eventManager; // the event manager to be created

    /**
     * Construct a status controller
     * @param eventManager : the eventManager to be assigned to the Logic.StatusController
     * @param alertManager : the alertManager to be assigned to the Logic.StatusController
     */
    public StatusController(EventManager eventManager, AlertManager alertManager) {
        this.alertManager = alertManager;
        this.eventManager = eventManager;
    }

    /**
     * Set status of events as past/ ongoing/ future according to current time
     * @param now the current time of the system
     */
    public void updateEventStatus(Date now,int userId) {
        for (Event event : eventManager.getAllEvents(userId)) {
            if (event.getStartTime().after(now)) {
                event.setStatus("Future");
                continue;
            }
            if (event.getEndTime().before(now)) {
                event.setStatus("Past");
            } else
                event.setStatus("Ongoing");
        }
    }

    /**
     * Check if two given time are equal time or not
     * @param d1: first given time
     * @param d2: second given time
     * @return: return true if two given time are the same, or false if two time are different
     */
    private boolean isEqualMinute(Date d1, Date d2) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(d1);
        c2.setTime(d2);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);
        c2.set(Calendar.SECOND, 0);
        c2.set(Calendar.MILLISECOND, 0);
        return c1.getTime().equals(c2.getTime());
    }

    /**
     * Display alerts if the alerts' setting notification is the same as given current time
     * @param now current time
     */
    public void arouseAlert(Date now) {
        for (Alert alert : alertManager.getAllAlert()) {
            if (isEqualMinute(alert.getTime(), now)) {
                setChanged();
                notifyObservers(alert);
            }
        }
    }

}
