package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.sample.data.event.Event;
import com.example.sample.data.memo.Memo;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Map;

/**
 *  The AddMemoActivity is a screen of the calendar app's interface
 *  when users' add memos
 */
public class AddMemoActivity extends AppCompatActivity {

    EditText eventNo, memo;
    Button createButton, returnButton;
    private User user;

    /**
     * Create all the static setup when creating the AddMemoActivity,
     * including initialization parts:
     * inflate the AddMemoActivity's UI
     * interact with widges in UI
     * bind data sets of memos to the list for a certain user
     * @param savedInstanceState a bundle containing the AddMemoActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_memo);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        eventNo = findViewById(R.id.et_event);
        memo = findViewById(R.id.et_memo);
        createButton = findViewById(R.id.btn_create);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                if(checkAdd()){
                    Event event = CalendarFacade.getInstance().getEventById(Integer.parseInt(eventNo.getText().toString().trim()));
                    int id = CalendarFacade.getInstance().getMemoMaxId();
                    Memo memoObject = new Memo(id+1, memo.getText().toString().trim(),event.getId(),user.getId());
                    CalendarFacade.getInstance().addMemo(memoObject);
                    writeMemoToFile(memoObject);
                    Intent intent = new Intent(AddMemoActivity.this, MemoManageActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putSerializable("user", user);
                    intent.putExtras(bundle);
                    startActivity(intent);
                    Toast.makeText(AddMemoActivity.this,"Add success！",Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(AddMemoActivity.this,"Add fail！",Toast.LENGTH_SHORT).show();
                }

            }
        });
        returnButton = findViewById(R.id.btn_return);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                finish();
            }
        });
    }

    /**
     * Check if it is a valid operation to add a memo to the system
     * @return return True if and only if the operation to add a memo is valid
     */
    private boolean checkAdd() {
        if(eventNo.getText().toString().isEmpty()){
            return false;
        } else{
            try{
                int id =  Integer.parseInt(eventNo.getText().toString().trim());
                if(CalendarFacade.getInstance().getEventById(id) == null){
                    Toast.makeText(AddMemoActivity.this,"Event not exist！",Toast.LENGTH_SHORT).show();
                    return false;
                }
            }catch (Exception e){
                return false;
            }
        }
        if(memo.getText().toString().isEmpty()){
            return false;
        }
        return true;
    }

    /**
     * write a memo of the system into file Memos.txt
     * @param memo the memo created and stored in the system which needs to be written in the Memos.txt file
     */
    private void writeMemoToFile(Memo memo) {
        try {
            FileOutputStream out = openFileOutput("Memos.csv", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            osw.write(memo.getId()+","+memo.getContext() +","+memo.getEventId()+","+memo.getUserId());
            osw.write("\n");
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}
