package com.example.sample.data.event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.CalendarBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * Manager of events
 */
public class EventManager {
    private List<Event> events; //list stores the event
    private int maxId; //the greatest id of used event

    /**
     * Constructs a manager of events
     */
    public EventManager() {
        maxId = 0;
        events = new ArrayList<>();
    }

    public void removeAll() {
        events = new ArrayList<>();
    }
    /**
     * add event to the list events and write events in Events.csv
     *
     * @param event event
     */
    public void addEvent(Event event) {
        if (event.getId() > maxId) {
            maxId = event.getId();
        }
        events.add(event);
        writeFile();
    }

    /**
     * get the greatest id of used events
     *
     * @return the greatest id of used events
     */
    public int getMaxId() {
        return maxId;
    }

    /**
     * get the list of all events
     *
     * @return the list of all events
     */
    public List<Event> getAllEvents(int id) {
        List<Event> myEvents = new ArrayList<>();
        User user = CalendarFacade.getInstance().getUserById(id);
        for(Event event: events){
            if(event.getUserId() == id || (event.getInviteUser().equals(user.getUserName()) && event.isConfirm())){
                myEvents.add(event);
            }
        }
        return myEvents;
    }

    public List<Event> getInviteEvents(int id) {
        List<Event> myEvents = new ArrayList<>();
        User user = CalendarFacade.getInstance().getUserById(id);
        for(Event event: events){
            if(event.getInviteUser() != null && event.getInviteUser().equals(user.getUserName()) && !event.isConfirm()){
                myEvents.add(event);
            }
        }
        return myEvents;
    }
    /**
     * get the list of all events
     *
     * @return the list of all events
     */
    public List<Event> getAllEvents() {
        return events;
    }

    /**
     * get the list of events in the status "Past"
     *
     * @return list of events in the status "Past"
     */
    public List<Event> getPastEvents(int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getStatus().equals("Past") && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * get the list of events in the status "Ongoing"
     *
     * @return list of events in the status "Ongoing"
     */
    public List<Event> getOngoingEvents(int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getStatus().equals("Ongoing") && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * get the list of events in the status "Future"
     *
     * @return list of events in the status "Future"
     */
    public List<Event> getFutureEvents(int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getStatus().equals("Future") && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * get the event with the given id, if there is no events satisfied the condition, return null
     *
     * @param id  id of the event
     * @return the event with the given id
     */
    public Event getEventById(int id) {
        for (Event event : events) {
            if (event.getId() == id) {
                return event;
            }
        }
        return null;
    }

    /**
     * get the list of events with given series name, if there is no events satisfied the condition
     *
     * @param series series name of the event
     * @return the list of events with given series name
     */
    public List<Event> getEventBySerires(String series,int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getSeriesName() != null && event.getSeriesName().equals(series) && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * get the list of events with given name
     *
     * @param name name of the event
     * @return the list of events with given name
     */
    public List<Event> getEventByName(String name,int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getName().equals(name) && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * get the list of events with given tag
     *
     * @param tag tag of the event
     * @return the list of events with given tag
     */
    public List<Event> getEventByTag(String tag, int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (event.getTag() != null && event.getTag().equals(tag) && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }

    /**
     * check whether d1 and d2 represent the same date
     *
     * @param d1 Date need to be compared
     * @param d2 Date need to be compared
     * @return true if d1 and d2 represent the same date, false if it doesn't
     */
    private boolean isEqualDate(Date d1, Date d2) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(d1);
        c2.setTime(d2);
        c1.set(Calendar.HOUR_OF_DAY, 0);
        c1.set(Calendar.MINUTE, 0);
        c1.set(Calendar.SECOND, 0);
        c1.set(Calendar.MILLISECOND, 0);
        c2.set(Calendar.HOUR_OF_DAY, 0);
        c2.set(Calendar.MINUTE, 0);
        c2.set(Calendar.SECOND, 0);
        c2.set(Calendar.MILLISECOND, 0);
        return c1.getTime().equals(c2.getTime());
    }

    /**
     * get the list of events with given date
     *
     * @param date date of the event
     * @return the list of events with given date
     */
    public List<Event> getEventByDate(Date date,int id) {
        List<Event> result = new ArrayList<>();
        for (Event event : events) {
            if (isEqualDate(event.getStartTime(), date) && event.getUserId() == id) {
                result.add(event);
            }
        }
        return result;
    }


    /**
     * write the Events in Events.csv
     */
    private void writeFile() {
        File file = new File("src/files/Events.csv");
        try {
            BufferedWriter writeText = new BufferedWriter(new FileWriter(file));
            for (Event event : events) {
                writeText.write(event.getId() + "," + event.getName() + "," + CalendarBuilder.SDF.format(event.getStartTime()) + ","
                        + CalendarBuilder.SDF.format(event.getEndTime()) + "," +
                        event.getSeriesName() + "," + event.getTag());
                writeText.newLine();
            }
            writeText.flush();
            writeText.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

}
