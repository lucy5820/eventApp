package com.example.sample;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.sample.data.alert.Alert;
import com.example.sample.data.event.Event;
import com.example.sample.data.user.User;
import com.example.sample.logic.CalendarFacade;
import com.example.sample.logic.builder.AlertBuilder;
import com.example.sample.logic.builder.CalendarBuilder;
import com.example.sample.logic.builder.FrequencyAlertBuilder;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.List;
import java.util.Map;

/**
 *  The AddAlertActivity is a screen of the calendar app's interface
 *  when users' add alerts to events
 */
public class AddAlertActivity extends AppCompatActivity {

    LinearLayout singleSetting, seriesSetting;
    Button createButton, returnButton;
    RadioGroup radioButton;
    EditText et_startTime, et_frequency,et_eventId;
    private int i;
    private User user;

    /**
     * Create all the static setup when creating the AddAlertActivity,
     * including initialization parts:
     * inflate the AddAlertActivity's UI
     * interact with widges in UI
     * bind data sets of alerts to the list for a certain user
     * @param savedInstanceState a bundle containing the LoginActivity's previously frozen state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_alert);
        radioButton = findViewById(R.id.filterOptions);
        et_eventId = findViewById(R.id.et_eventId);
        singleSetting = (LinearLayout) findViewById(R.id.singleSettings);
        singleSetting.setVisibility(View.GONE);
        Bundle bundle = getIntent().getExtras();
        if( bundle != null) {
            user = (User) bundle.getSerializable("user");
        }
        seriesSetting = (LinearLayout) findViewById(R.id.seriesSettings);
        singleSetting.setVisibility(View.GONE);
        radioButton.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup unused, int checkedId) {
                // checkedId is the R.id constant of the currently checked RadioButton
                // Your code here: make only the selected mode's settings group visible
                if (checkedId == R.id.single) {
                    i = 0;
                    seriesSetting.setVisibility(View.GONE);
                    singleSetting.setVisibility(View.VISIBLE);
                    et_startTime = findViewById(R.id.et_startTime);
                }

                if (checkedId == R.id.series) {
                    i = 1;
                    singleSetting.setVisibility(View.GONE);
                    seriesSetting.setVisibility(View.VISIBLE);
                    et_frequency = findViewById(R.id.et_frequency);
                }
            }
        });

        createButton = findViewById(R.id.btn_create);
        createButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                    if(i == 0){
                        if(checkAdd(0)) {
                            int maxID = CalendarFacade.getInstance().getAlertMaxId();
                            Event event = CalendarFacade.getInstance().getEventById(Integer.parseInt(et_eventId.getText().toString().trim()));
                            AlertBuilder alertBuilder = new AlertBuilder(maxID+1);
                            alertBuilder.constructAlert(et_startTime.getText().toString().trim(), user.getId(), event.getId());
                            Alert alert = alertBuilder.getAlert();
                            CalendarFacade.getInstance().addAlert(alert);
                            writeAlert(alert);
                            finish();
                            Toast.makeText(AddAlertActivity.this,"Add success！",Toast.LENGTH_SHORT).show();
                        }
                    }else if(i == 1){
                        if(checkAdd(1)) {
                            int maxID = CalendarFacade.getInstance().getAlertMaxId();
                            Event event = CalendarFacade.getInstance().getEventById(Integer.parseInt(et_eventId.getText().toString().trim()));
                            FrequencyAlertBuilder frequencyAlertBuilder = new FrequencyAlertBuilder(maxID+1,event.getStartTime());
                            frequencyAlertBuilder.constructFrequencyAlert(et_frequency.getText().toString().trim(), user.getId(),event.getId());
                            List<Alert> alerts = frequencyAlertBuilder.getFrequencyAlerts();
                            for (Alert alert : alerts) {
                                CalendarFacade.getInstance().addAlert(alert);
                            }
                            writeAlertsToFile(alerts);
                            finish();
                            Toast.makeText(AddAlertActivity.this,"Add success！",Toast.LENGTH_SHORT).show();
                        }
                    }



            }
        });
        returnButton = findViewById(R.id.btn_return);
        returnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //where it will transfer to after click the button
                finish();
            }
        });
    }

    /**
     * Check if it is a valid operation to add an alert to the system
     * @param i represent they type of the event to added
     * @return return True if and only if the operation to add an alert is valid
     */
    private boolean checkAdd(int i) {
        if(et_eventId.getText().toString().isEmpty()){
            Toast.makeText(AddAlertActivity.this,"Can not empty！",Toast.LENGTH_SHORT).show();
            return false;
        } else{
            try{
               int id =  Integer.parseInt(et_eventId.getText().toString().trim());
               if(CalendarFacade.getInstance().getEventById(id) == null){
                   Toast.makeText(AddAlertActivity.this,"Event not exist！",Toast.LENGTH_SHORT).show();
                   return false;
               }
            }catch (Exception e){
                Toast.makeText(AddAlertActivity.this,"Event id should be number！",Toast.LENGTH_SHORT).show();
                return false;
            }

        }
        if(i == 0){
            if(!isVaildTime(et_startTime.getText().toString().trim())){
                Toast.makeText(AddAlertActivity.this,"Date format yyyy-MM-dd HH:mm！",Toast.LENGTH_SHORT).show();
                return false;
            }
        } else if(i == 1){
            if(!isValidFrequency(et_frequency.getText().toString().trim())){
                Toast.makeText(AddAlertActivity.this,"format: day,hours ex. 2,23 means set the alert every 2 days and 23 hours！",Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        return true;
    }

    /**
     * Check if the input time is a valid time or not
     * @param time : the input time
     * @return: return true if the input time is valid, false if not
     */
    private boolean isVaildTime(String time) {
        try {
            CalendarBuilder.SDF.parse(time);
        } catch (Exception e) {
            return false;
        }
        return true;
    }

    /**
     * Check if the input frequency is a valid frequency or not
     * @param frequency : the input frequency defined by user
     * @return: return true if the input frequency is valid, false if not
     */
    private boolean isValidFrequency(String frequency) {
        if (!frequency.contains(",") || frequency.charAt(0) == ',') {
            return false;
        }
        String[] daysHours = frequency.split(",");
        if (daysHours.length < 2) {
            return false;
        }
        char[] days = daysHours[0].toCharArray();
        char[] hours = daysHours[1].toCharArray();
        if (Integer.parseInt(daysHours[1]) >= 24 || (days.length > 1 && days[0] == '0') || (hours.length > 1 && hours[0] == '0')) {
            return false;
        }
        for (char c : days) {
            for (char h : hours) {
                if (!Character.isDigit(c) || !Character.isDigit(h)) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * write the data set of the list of alerts of the system into file Alerts.txt
     * @param alerts the list of alerts created and stored in the system
     */
    private void writeAlertsToFile(List<Alert> alerts) {
        try {
            FileOutputStream out = openFileOutput("Alerts.txt", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            for (Alert alert : alerts) {
                osw.write(alert.getId() + "," + CalendarBuilder.SDF.format(alert.getTime()) + "," + alert.getUserId() + "," + alert.getEventId());
                osw.write("\n");
            }
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }

    /**
     * write a single alert of the system into file Alerts.txt
     * @param alert the alert created and stored in the system which needs to be written in the Alerts.txt file
     */
    private void writeAlert(Alert alert) {
        try {
            FileOutputStream out = openFileOutput("Alerts.txt", Context.MODE_APPEND);
            OutputStreamWriter osw = new OutputStreamWriter(out);
            osw.write(alert.getId() + "," + CalendarBuilder.SDF.format(alert.getTime())+ "," + alert.getUserId() + "," + alert.getEventId());
            osw.write("\n");
            osw.flush();
            osw.close();
        } catch (IOException e) {
            System.out.println("Writing Error");
        }
    }


}
